#!/usr/bin/env python3
# =====================================================
# EMAIL HANDLER - Daily Report Email via Outlook
# =====================================================

import logging
from datetime import datetime
import win32com.client as win32
from config import (
    EMAIL_ENABLED, EMAIL_RECIPIENT, EMAIL_CC_LIST,
    COMPANY_NAME, INSPECTION_MANAGER, DB_MODE
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter('[EMAIL] %(message)s'))
logger.addHandler(handler)


def get_todays_stats():
    """Fetch today's inspection statistics from database."""
    from datetime import datetime, timedelta
    
    if DB_MODE == "mysql":
        from db_handler import get_connection
        try:
            today = datetime.now().date()
            with get_connection() as conn:
                cursor = conn.cursor(dictionary=True)
                
                # Get today's measurements
                query = """
                    SELECT 
                        status,
                        COUNT(*) as count,
                        GROUP_CONCAT(DISTINCT reason SEPARATOR ', ') as reasons
                    FROM measurements
                    WHERE DATE(inspection_date) = %s
                    GROUP BY status
                """
                cursor.execute(query, (today,))
                results = cursor.fetchall()
                
                stats = {
                    'ok': 0,
                    'not_ok': 0,
                    'pending': 0,
                    'not_ok_reasons': []
                }
                
                for row in results:
                    status = row['status'].lower()
                    count = row['count']
                    
                    if status == 'ok':
                        stats['ok'] = count
                    elif status == 'not_ok' or status == 'fail':
                        stats['not_ok'] = count
                        if row['reasons']:
                            stats['not_ok_reasons'] = row['reasons'].split(', ')
                    elif status == 'pending':
                        stats['pending'] = count
                
                return stats
        except Exception as e:
            logger.error(f"Error fetching stats: {e}")
            return None
    else:
        # Legacy Excel mode - not implemented for email
        logger.warning("Email reports not yet supported for Excel mode")
        return None


def generate_html_report(stats):
    """Generate HTML email body with today's statistics."""
    if not stats:
        stats = {'ok': 0, 'not_ok': 0, 'pending': 0, 'not_ok_reasons': []}
    
    total = stats['ok'] + stats['not_ok'] + stats['pending']
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    reasons_html = ""
    if stats.get('not_ok_reasons'):
        reasons_html = """
        <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><b>Failure Reasons:</b></td>
            <td style="padding: 10px; border: 1px solid #ddd;">
                <ul style="margin: 0; padding-left: 20px;">
        """
        for reason in stats['not_ok_reasons']:
            reasons_html += f"<li>{reason}</li>"
        reasons_html += """
                </ul>
            </td>
        </tr>
        """
    
    html = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
            .container {{ background-color: white; padding: 20px; border-radius: 8px; }}
            .header {{ background-color: #003d7a; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
            .header h1 {{ margin: 0; font-size: 24px; }}
            .header p {{ margin: 5px 0 0 0; font-size: 12px; }}
            .stats-table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            .stats-table th, .stats-table td {{ text-align: left; padding: 12px; border: 1px solid #ddd; }}
            .stats-table th {{ background-color: #f0f0f0; font-weight: bold; }}
            .stat-box {{ display: inline-block; margin: 10px 20px 10px 0; }}
            .stat-number {{ font-size: 32px; font-weight: bold; color: #003d7a; }}
            .stat-label {{ font-size: 14px; color: #666; }}
            .ok {{ color: #28a745; }}
            .not-ok {{ color: #dc3545; }}
            .pending {{ color: #ffc107; }}
            .footer {{ margin-top: 20px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>{COMPANY_NAME} - Daily Inspection Report</h1>
                <p>Generated: {timestamp}</p>
            </div>
            
            <h2>Today's Summary ({datetime.now().strftime('%Y-%m-%d')})</h2>
            
            <div>
                <div class="stat-box">
                    <div class="stat-number ok">✓ {stats['ok']}</div>
                    <div class="stat-label">OK Parts</div>
                </div>
                
                <div class="stat-box">
                    <div class="stat-number not-ok">✗ {stats['not_ok']}</div>
                    <div class="stat-label">Not OK Parts</div>
                </div>
                
                <div class="stat-box">
                    <div class="stat-number pending">⏳ {stats['pending']}</div>
                    <div class="stat-label">Pending</div>
                </div>
                
                <div class="stat-box">
                    <div class="stat-number" style="color: #333;">∑ {total}</div>
                    <div class="stat-label">Total Inspections</div>
                </div>
            </div>
            
            <h3>Detailed Statistics</h3>
            <table class="stats-table">
                <tr>
                    <th>Metric</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td><span class="ok"><b>✓ OK Parts</b></span></td>
                    <td><b>{stats['ok']}</b> ({(stats['ok']/total*100):.1f}% of total)</td>
                </tr>
                <tr>
                    <td><span class="not-ok"><b>✗ Not OK Parts</b></span></td>
                    <td><b>{stats['not_ok']}</b> ({(stats['not_ok']/total*100):.1f}% of total)</td>
                </tr>
                <tr>
                    <td><span class="pending"><b>⏳ Pending</b></span></td>
                    <td><b>{stats['pending']}</b> ({(stats['pending']/total*100):.1f}% of total)</td>
                </tr>
                {reasons_html}
                <tr>
                    <td><b>Total Inspections</b></td>
                    <td><b>{total}</b></td>
                </tr>
            </table>
            
            <div class="footer">
                <p><b>From:</b> MCP Vernier Inspector System</p>
                <p><b>Recipient:</b> {INSPECTION_MANAGER}</p>
                <p><i>This is an automated daily report. Please do not reply to this email.</i></p>
            </div>
        </div>
    </body>
    </html>
    """
    return html


def send_email_via_outlook(subject, html_body, recipient_email=None, cc_list=None):
    """Send email via Outlook using Windows COM interface."""
    try:
        if not recipient_email:
            recipient_email = EMAIL_RECIPIENT
        
        if not cc_list:
            cc_list = EMAIL_CC_LIST
        
        # Initialize Outlook
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)  # 0 = email item
        
        # Set email properties
        mail.Subject = subject
        mail.HTMLBody = html_body
        mail.To = recipient_email
        
        if cc_list and cc_list[0]:
            mail.CC = ";".join([cc.strip() for cc in cc_list if cc.strip()])
        
        # Send the email
        mail.Send()
        logger.info(f"Email sent successfully to {recipient_email}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending email: {e}")
        return False


def send_daily_report():
    """Generate and send the daily inspection report."""
    try:
        if not EMAIL_ENABLED:
            logger.info("Email reporting is disabled")
            return False
        
        logger.info("Generating daily inspection report...")
        
        # Get today's statistics
        stats = get_todays_stats()
        if stats is None:
            logger.error("Failed to retrieve today's statistics")
            return False
        
        # Generate HTML report
        html_body = generate_html_report(stats)
        
        # Prepare email subject
        subject = f"{COMPANY_NAME} Inspection Report - {datetime.now().strftime('%Y-%m-%d')}"
        
        # Send email
        success = send_email_via_outlook(subject, html_body)
        
        if success:
            logger.info("Daily report email sent successfully")
        
        return success
        
    except Exception as e:
        logger.error(f"Error in send_daily_report: {e}")
        return False


def test_email_connection():
    """Test email configuration by sending a test email."""
    try:
        test_html = """
        <html>
        <body>
            <h2>Test Email - MCP Vernier Inspector</h2>
            <p>If you received this email, your email configuration is working correctly.</p>
            <p><b>Time:</b> """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</p>
        </body>
        </html>
        """
        
        subject = f"[TEST] {COMPANY_NAME} - Email Configuration Test"
        success = send_email_via_outlook(subject, test_html)
        
        return success
    except Exception as e:
        logger.error(f"Error in test_email_connection: {e}")
        return False


if __name__ == "__main__":
    print("[EMAIL] Testing email handler...")
    test_email_connection()
