# =====================================================
# MITUTOYO U-WAVE-TCB (BLUETOOTH LE) — KEYBOARD-WEDGE READER
# =====================================================
#
# Hardware path:
#   Mitutoyo caliper (Digimatic)
#       → U-WAVE-TCB transmitter  (Bluetooth 4.2 Low Energy)
#       → Windows Bluetooth pairing  (NO COM port is created — BLE
#         devices are never exposed as a virtual serial port)
#       → Mitutoyo's PC software (U-WAVEPAK-BW / USB-ITPAK), configured
#         to output each reading as KEYBOARD KEYSTROKES ending in Enter
#         — the same "keyboard wedge" trick barcode scanners use.
#       → Browser captures the keystrokes with a hidden <input>
#       → POST /api/vernier_hid  →  this module
#
# This module intentionally exposes the SAME public function names as
# bluetooth_reader.py (connect, read_measurement, get_pending_channel,
# get_channel_progress, reset_channel_buffer, get_connection_status,
# list_available_ports, get_last_raw) so app.py can import from EITHER
# module interchangeably depending on MITUTOYO_MODE in config.py.
#
# Channel workflow (identical to the serial version):
#   DATA press 1 → CEC_TK arrives
#   DATA press 2 → ROD_TK arrives
#   DATA press 3 → MF arrives
#   All 3 done → read_measurement() returns {"CEC_TK":x,"ROD_TK":y,"MF":z}
# =====================================================

import re
import threading

from config import CHANNEL_ORDER

# MODULE STATE  (all protected by _lock)
_lock        = threading.Lock()
_channel_buf = {}     # {channel_name: float}  e.g. {"CEC_TK": 119.5}
_last_raw    = ""     # last raw string received, for diagnostics


# VALUE PARSER
def _parse_value(raw: str):
    """
    Extract a float mm value from whatever the U-WAVEPAK-BW keyboard-wedge
    software typed. Handles values with or without a decimal point, and
    optional leading +/- sign, e.g. '119.500', '+119.500', '119500'.
    """
    global _last_raw
    _last_raw = raw
    text = (raw or "").strip()
    clean = re.sub(r"[^\d+\-.]", "", text)
    if not clean:
        return None
    try:
        return round(float(clean), 4)
    except ValueError:
        return None


# PUBLIC MEASUREMENT API  (called from the /api/vernier_hid endpoint)
def push_hid_reading(raw: str):
    """
    Called by the Flask endpoint when the browser captures a keystroke
    line from the U-WAVE-TCB keyboard-wedge software. Assigns the parsed
    value to the next unfilled channel in CHANNEL_ORDER.
    Returns the parsed float, or None if it couldn't be parsed.
    """
    val = _parse_value(raw)
    if val is None:
        return None
    with _lock:
        for ch in CHANNEL_ORDER:
            if ch not in _channel_buf:
                _channel_buf[ch] = val
                print(f"[Vernier-HID] {ch} = {val} mm  "
                      f"(channel {len(_channel_buf)}/{len(CHANNEL_ORDER)})")
                break
    return val


def read_measurement():
    """
    Called by Flask poll every ~600 ms (same contract as bluetooth_reader.py).
    Returns complete dict once all 3 channels are filled, else None.
    """
    with _lock:
        if _channel_buf and all(ch in _channel_buf for ch in CHANNEL_ORDER):
            result = dict(_channel_buf)
            _channel_buf.clear()
            return result
    return None


def get_pending_channel():
    """Return the name of the next channel awaiting a reading, or None if all done."""
    with _lock:
        for ch in CHANNEL_ORDER:
            if ch not in _channel_buf:
                return ch
    return None


def get_channel_progress():
    """Return current collection state, e.g. {"CEC_TK": 119.5, "ROD_TK": None, "MF": None}."""
    with _lock:
        return {ch: _channel_buf.get(ch) for ch in CHANNEL_ORDER}


def reset_channel_buffer():
    """Discard any partially-collected measurement and start fresh."""
    with _lock:
        _channel_buf.clear()
    print("[Vernier-HID] Channel buffer reset")


def clear_channel(channel: str):
    """
    Discard just ONE channel's reading (e.g. operator pressed DATA at the
    wrong moment and wants to re-measure only that dimension), leaving any
    other already-collected channels intact.
    """
    with _lock:
        _channel_buf.pop(channel, None)
    print(f"[Vernier-HID] Cleared channel {channel}")


def get_last_raw() -> str:
    return _last_raw


# CONNECTION-STATUS STAND-INS
# There is no serial port in HID mode, so these exist only so app.py can
# call the same function names regardless of which reader module is active.
def get_connection_status() -> str:
    return "hid"


def list_available_ports() -> list:
    return []


def connect(port: str = None) -> bool:
    return True
