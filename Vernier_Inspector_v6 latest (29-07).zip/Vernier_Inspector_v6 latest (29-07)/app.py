# =====================================================
# MAIN APPLICATION  —  MCP Vernier Inspector v2.0
# =====================================================
import csv
import io
from datetime import datetime

from flask import (Flask, Response, jsonify, redirect,
                   render_template, request, session, url_for)

#  Hardware: Mitutoyo vernier 
# MITUTOYO_MODE "serial" → bluetooth_reader.py   (U-WAVE-T/TM/TC + U-WAVE-R dongle)
# MITUTOYO_MODE "hid"    → vernier_hid_reader.py (U-WAVE-TCB Bluetooth LE, keyboard-wedge)
from config import MITUTOYO_MODE as _MITUTOYO_MODE
try:
    if _MITUTOYO_MODE == "hid":
        from vernier_hid_reader import (
            clear_channel,
            connect         as mitutoyo_connect,
            get_channel_progress,
            get_connection_status,
            get_last_raw,
            get_pending_channel,
            list_available_ports,
            push_hid_reading,
            read_measurement,
            reset_channel_buffer,
        )
    else:
        from bluetooth_reader import (
            clear_channel,
            connect         as mitutoyo_connect,
            get_channel_progress,
            get_connection_status,
            get_last_raw,
            get_pending_channel,
            list_available_ports,
            read_measurement,
            reset_channel_buffer,
        )
        def push_hid_reading(raw):  return None   # not used in serial mode
    _MITUTOYO_OK = True
except Exception as _e:
    print(f"[App] vernier reader import failed ({_MITUTOYO_MODE} mode): {_e}")
    _MITUTOYO_OK = False
    def read_measurement():         return None
    def get_connection_status():    return "disconnected"
    def get_pending_channel():      return "CEC_TK"
    def get_channel_progress():     return {"CEC_TK": None, "ROD_TK": None, "MF": None}
    def reset_channel_buffer():     pass
    def clear_channel(ch):          pass
    def list_available_ports():     return []
    def mitutoyo_connect(p=None):   return False
    def get_last_raw():             return ""
    def push_hid_reading(raw):      return None

#  Hardware: Honeywell 1470G scanner 
try:
    from scanner_reader import (
        get_latest_scan,
        get_scanner_status,
        list_scanner_ports,
        push_hid_scan,
        start_scanner,
    )
    _SCANNER_OK = True
except Exception as _e:
    print(f"[App] scanner_reader import failed: {_e}")
    _SCANNER_OK = False
    def start_scanner():            pass
    def get_latest_scan():          return None
    def get_scanner_status():       return "hid"
    def push_hid_scan(b):           pass
    def list_scanner_ports():       return []

#  Data layer 
from excel_handler import (
    check_measurement,
    create_files,
    get_all_brands,
    get_all_measurements,
    get_all_ranges,
    get_failure_detail,
    get_nominal_data,
    get_range_for_part,
    get_report_summary,
    save_measurement,
)
from config import (
    ADMIN_PASSWORD, ADMIN_USERNAME,
    AUTO_SAVE, MITUTOYO_PORT,
    OPERATOR_PASSWORD, OPERATOR_USERNAME,
    SCANNER_MODE, SCANNER_PORT,
    SECRET_KEY, UNIT, EMAIL_ENABLED,
)

# Email & Scheduler
try:
    from email_handler import send_daily_report, test_email_connection
    from scheduler import start_scheduler, get_scheduler_status
    _EMAIL_OK = True
except Exception as _e:
    print(f"[App] email_handler import failed: {_e}")
    _EMAIL_OK = False
    def send_daily_report():      return False
    def test_email_connection():  return False
    def start_scheduler():        pass
    def get_scheduler_status():   return {'enabled': False, 'running': False}

# FLASK APP
app = Flask(__name__)
app.secret_key = SECRET_KEY

create_files()
start_scanner()
if EMAIL_ENABLED:
    start_scheduler()
    print("[App] Email scheduler started")


# AUTH HELPERS
def logged_in() -> bool:
    return "user" in session

def is_admin() -> bool:
    return session.get("role") == "admin"


# LOGIN / LOGOUT
@app.route("/", methods=["GET", "POST"])
def login():
    if logged_in():
        return redirect(url_for("dashboard"))
    error = None
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if u == ADMIN_USERNAME and p == ADMIN_PASSWORD:
            session.update({"user": u, "role": "admin"})
            return redirect(url_for("dashboard"))
        if u == OPERATOR_USERNAME and p == OPERATOR_PASSWORD:
            session.update({"user": u, "role": "operator"})
            return redirect(url_for("dashboard"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# DASHBOARD  &  SETUP
@app.route("/dashboard")
def dashboard():
    if not logged_in():
        return redirect(url_for("login"))
    return render_template(
        "dashboard.html",
        username      = session["user"],
        role          = session.get("role", "operator"),
        unit          = UNIT,
        mitutoyo_port = MITUTOYO_PORT,
        mitutoyo_mode = _MITUTOYO_MODE,
        scanner_mode  = SCANNER_MODE,
        auto_save     = AUTO_SAVE,
    )


@app.route("/setup")
def setup():
    if not logged_in():
        return redirect(url_for("login"))
    return render_template(
        "setup.html",
        mitutoyo_ports = list_available_ports(),
        scanner_ports  = list_scanner_ports(),
        config = {
            "mitutoyo_port": MITUTOYO_PORT,
            "scanner_mode":  SCANNER_MODE,
            "scanner_port":  SCANNER_PORT,
        },
    )


# API — DEVICE STATUS
@app.route("/api/device_status")
def api_device_status():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify({
        "mitutoyo":        get_connection_status(),
        "scanner":         get_scanner_status(),
        "pending_channel": get_pending_channel(),
        "progress":        get_channel_progress(),
        "mitutoyo_ports":  list_available_ports(),
        "scanner_ports":   list_scanner_ports(),
        "last_raw":        get_last_raw(),
    })


# API — LIVE MEASUREMENT  (poll every 600 ms)
@app.route("/api/live_measurement")
def api_live_measurement():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401

    data    = read_measurement()    # dict or None
    pending = get_pending_channel()
    prog    = get_channel_progress()

    if data is None:
        # No complete measurement yet — return progress state
        return jsonify({
            "complete":        False,
            "pending_channel": pending,
            "progress":        prog,
            "mitutoyo_status": get_connection_status(),
        })

    # Complete measurement received: data = {"CEC_TK": x, "ROD_TK": y, "MF": z}
    part_no = session.get("current_part_no", "")
    status  = None
    issues  = []
    if part_no:
        status = check_measurement(part_no, data["CEC_TK"], data["ROD_TK"], data["MF"])
        if status == "NOT OK":
            issues = get_failure_detail(part_no, data["CEC_TK"], data["ROD_TK"], data["MF"])

    result = {
        "complete":        True,
        "CEC_TK":          data["CEC_TK"],
        "ROD_TK":          data["ROD_TK"],
        "MF":              data["MF"],
        "mitutoyo_status": get_connection_status(),
        "status":          status,
        "issues":          issues,
    }

    # Auto-save if configured
    if AUTO_SAVE and part_no and status:
        now = datetime.now()
        save_measurement(
            now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S"),
            part_no, data["CEC_TK"], data["ROD_TK"], data["MF"], status,
        )
        session.pop("current_part_no", None)
        reset_channel_buffer()
        result["auto_saved"] = True

    return jsonify(result)


@app.route("/api/reset_measurement", methods=["POST"])
def api_reset_measurement():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    reset_channel_buffer()
    return jsonify({"ok": True})


@app.route("/api/reset_channel", methods=["POST"])
def api_reset_channel():
    """
    Clear a single measurement channel (CEC_TK / ROD_TK / MF) so the
    operator can re-take just that one reading without losing the others —
    e.g. they pressed DATA at the wrong moment on the caliper.
    """
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    channel = str(request.get_json(force=True).get("channel", "")).strip()
    if channel not in ("CEC_TK", "ROD_TK", "MF"):
        return jsonify({"error": "invalid channel"}), 400
    clear_channel(channel)
    return jsonify({"ok": True, "channel": channel})


# API — SCANNER
@app.route("/api/hid_scan", methods=["POST"])
def api_hid_scan():
    """
    Called by the browser when the HID scanner sends a barcode.
    The browser's JS keystroke capture sends the full barcode string here.
    """
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    barcode = str(request.get_json(force=True).get("barcode", "")).strip()
    if not barcode:
        return jsonify({"error": "empty barcode"}), 400

    session["current_part_no"] = barcode
    rng = get_range_for_part(barcode)
    return jsonify({
        "part_no": barcode,
        "found":   rng is not None,
        "range":   rng,
    })


# API — VERNIER (U-WAVE-TCB keyboard-wedge mode)
@app.route("/api/vernier_hid", methods=["POST"])
def api_vernier_hid():
    """
    Called by the browser when the U-WAVEPAK-BW keyboard-wedge software
    types a measurement reading (only active when MITUTOYO_MODE = "hid").
    """
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    raw = str(request.get_json(force=True).get("value", "")).strip()
    if not raw:
        return jsonify({"error": "empty value"}), 400
    val = push_hid_reading(raw)
    if val is None:
        return jsonify({"ok": False, "error": "could not parse value", "raw": raw}), 400
    return jsonify({"ok": True, "value": val, "pending_channel": get_pending_channel()})


@app.route("/api/latest_scan")
def api_latest_scan():
    """Poll endpoint for serial-mode scanner (SCANNER_MODE = 'serial')."""
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    barcode = get_latest_scan()
    if barcode:
        session["current_part_no"] = barcode
        rng = get_range_for_part(barcode)
        return jsonify({
            "scanned": True,
            "part_no": barcode,
            "found":   rng is not None,
            "range":   rng,
        })
    return jsonify({"scanned": False})


@app.route("/api/set_part_no", methods=["POST"])
def api_set_part_no():
    """Manual part number entry from the dashboard input field."""
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    part_no = str(request.get_json(force=True).get("part_no", "")).strip().upper()
    if not part_no:
        return jsonify({"error": "part_no required"}), 400
    session["current_part_no"] = part_no
    rng = get_range_for_part(part_no)
    return jsonify({"part_no": part_no, "found": rng is not None, "range": rng})


@app.route("/api/current_part")
def api_current_part():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    part_no = session.get("current_part_no", "")
    rng = get_range_for_part(part_no) if part_no else None
    return jsonify({"part_no": part_no, "range": rng})


# API — SAVE MEASUREMENT
@app.route("/api/save_measurement", methods=["POST"])
def api_save_measurement():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    body    = request.get_json(force=True)
    part_no = str(body.get("part_no", "")).strip().upper()
    cec_tk  = float(body["CEC_TK"])
    rod_tk  = float(body["ROD_TK"])
    mf      = float(body["MF"])
    if not part_no:
        return jsonify({"error": "part_no required"}), 400

    status = check_measurement(part_no, cec_tk, rod_tk, mf)
    issues = get_failure_detail(part_no, cec_tk, rod_tk, mf) if status == "NOT OK" else []

    now = datetime.now()
    save_measurement(
        now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S"),
        part_no, cec_tk, rod_tk, mf, status,
    )
    session.pop("current_part_no", None)
    reset_channel_buffer()
    return jsonify({"status": status, "issues": issues})


# API — DATA READS
@app.route("/api/output_data")
def api_output_data():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_all_measurements())


@app.route("/api/ranges")
def api_ranges():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_all_ranges())


@app.route("/api/part_catalog")
def api_part_catalog():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_nominal_data())


@app.route("/api/brands")
def api_brands():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_all_brands())


@app.route("/api/part_lookup/<path:part_no>")
def api_part_lookup(part_no):
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    rng = get_range_for_part(part_no)
    if rng is None:
        return jsonify({"found": False}), 404
    return jsonify({"found": True, "range": rng})


@app.route("/api/report_summary")
def api_report_summary():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_report_summary())


# API — SETUP
@app.route("/api/setup/connect_mitutoyo", methods=["POST"])
def api_setup_connect_mitutoyo():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    port = request.get_json(force=True).get("port", MITUTOYO_PORT)
    ok   = mitutoyo_connect(port)
    return jsonify({"connected": ok, "status": get_connection_status()})


# EXPORT — CSV
@app.route("/export/csv")
def export_csv():
    if not logged_in():
        return redirect(url_for("login"))
    rows = get_all_measurements()
    buf  = io.StringIO()
    w    = csv.writer(buf)
    w.writerow([
        "Date", "Time", "Part No", "Brand",
        f"CEC TK ({UNIT})", f"ROD TK ({UNIT})", f"MF ({UNIT})", "Status",
    ])
    for m in rows:
        w.writerow([
            m["date"], m["time"], m["part_no"], m.get("brand", ""),
            m["CEC_TK"], m["ROD_TK"], m["MF"], m["status"],
        ])
    fname = f"MCP_inspection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        buf.getvalue(),
        mimetype = "text/csv",
        headers  = {"Content-Disposition": f"attachment; filename={fname}"},
    )


# API — EMAIL MANAGEMENT (Admin only)
@app.route("/api/email/send_report", methods=["POST"])
def api_send_report():
    """Manually trigger daily report email."""
    if not logged_in() or not is_admin():
        return jsonify({"error": "Unauthorized"}), 403
    
    success = send_daily_report()
    return jsonify({
        "success": success,
        "message": "Report sent successfully" if success else "Failed to send report"
    })


@app.route("/api/email/test", methods=["POST"])
def api_test_email():
    """Send a test email to verify configuration."""
    if not logged_in() or not is_admin():
        return jsonify({"error": "Unauthorized"}), 403
    
    success = test_email_connection()
    return jsonify({
        "success": success,
        "message": "Test email sent successfully" if success else "Failed to send test email"
    })


@app.route("/api/email/status")
def api_email_status():
    """Get email scheduler status."""
    if not logged_in() or not is_admin():
        return jsonify({"error": "Unauthorized"}), 403
    
    return jsonify({
        "enabled": EMAIL_ENABLED,
        "scheduler": get_scheduler_status()
    })


# Run
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
