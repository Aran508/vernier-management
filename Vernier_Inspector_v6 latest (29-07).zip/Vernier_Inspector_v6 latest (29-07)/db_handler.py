#!/usr/bin/env python3
# =====================================================
# DATABASE HANDLER - MySQL Backend for MCP Inspector
# FIXED VERSION - Correct column mapping
# =====================================================

import mysql.connector
from mysql.connector import Error, errorcode
from contextlib import contextmanager
import logging

from config import DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter('[DB] %(message)s'))
logger.addHandler(handler)


# =====================================================
# DATABASE CONNECTION
# =====================================================

@contextmanager
def get_connection():
    """Context manager for database connections."""
    conn = None
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        yield conn
    except Error as e:
        if e.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            logger.error("Something is wrong with your user name or password")
        elif e.errno == errorcode.ER_BAD_DB_ERROR:
            logger.error("Database does not exist")
        else:
            logger.error(f"Error: {e}")
        raise
    finally:
        if conn and conn.is_connected():
            conn.close()


def test_connection() -> bool:
    """Test database connection."""
    try:
        with get_connection() as conn:
            logger.info("Connection test successful")
            return True
    except Exception as e:
        logger.error(f"Connection test failed: {e}")
        return False


def initialize_database() -> bool:
    """Initialize database tables if they don't exist."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            # Check if tables exist
            cursor.execute("SHOW TABLES")
            tables = [row[0] for row in cursor.fetchall()]
            
            if 'part_numbers' not in tables:
                logger.warning("Database tables not initialized")
                cursor.close()
                return False
            
            logger.info("Database initialized successfully")
            cursor.close()
            return True
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False


# =====================================================
# BRANDS
# =====================================================

def add_brand(brand_name: str) -> int:
    """Add a brand. Returns brand_id or -1 on error."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT IGNORE INTO brands (brand_name) VALUES (%s)",
                (brand_name,)
            )
            conn.commit()
            
            # Get the brand_id
            cursor.execute("SELECT brand_id FROM brands WHERE brand_name = %s", (brand_name,))
            result = cursor.fetchone()
            cursor.close()
            
            if result:
                logger.info(f"Added brand: {brand_name}")
                return result[0]
            return -1
    except Exception as e:
        logger.error(f"Error adding brand {brand_name}: {e}")
        return -1


def get_all_brands() -> list:
    """Get all brands."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM brands ORDER BY brand_name")
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting brands: {e}")
        return []

# =====================================================
# PART NUMBERS & NOMINALS
# =====================================================

def add_part_number(part_no: str, brand_name: str = None, description: str = None,
                    mf_nom=None, cec_nom=None, rod_nom=None,
                    stroke_nom=None, closed_nom=None) -> int:
    """
    Add a part number with nominal values.
    Returns part_id or -1 on error.
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            # Get brand_id
            brand_id = None
            if brand_name:
                cursor.execute("SELECT brand_id FROM brands WHERE brand_name = %s", (brand_name,))
                result = cursor.fetchone()
                if result:
                    brand_id = result[0]
            
            # Insert part
            cursor.execute(
                """INSERT IGNORE INTO part_numbers 
                   (part_no, brand_id, part_description, mounting_face_nominal, 
                    cec_thickness_nominal, rod_eye_thickness_nominal,
                    stroke_length_nominal, closed_length_nominal)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                (part_no, brand_id, description, mf_nom, cec_nom, rod_nom, stroke_nom, closed_nom)
            )
            conn.commit()
            
            # Get the part_id
            cursor.execute("SELECT part_id FROM part_numbers WHERE part_no = %s", (part_no,))
            result = cursor.fetchone()
            cursor.close()
            
            if result:
                logger.info(f"Added part number: {part_no}")
                return result[0]
            return -1
    except Exception as e:
        logger.error(f"Error adding part {part_no}: {e}")
        return -1


def get_nominal_data() -> list:
    """Get all part numbers with nominal values."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT p.part_id, p.part_no, b.brand_name AS brand, p.part_description,
                       p.mounting_face_nominal , p.cec_thickness_nominal, 
                       p.rod_eye_thickness_nominal, p.stroke_length_nominal, 
                       p.closed_length_nominal
                FROM part_numbers p
                LEFT JOIN brands b ON p.brand_id = b.brand_id
                ORDER BY p.part_no
            """)
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting nominal data: {e}")
        return []


# =====================================================
# TOLERANCE RANGES
# =====================================================

def add_tolerance_range(part_id: int, brand_id=None,
                       mf_min=None, mf_max=None,
                       cec_min=None, cec_max=None,
                       rod_min=None, rod_max=None,
                       stroke_min=None, stroke_max=None,
                       closed_min=None, closed_max=None) -> bool:
    """Add or update tolerance range for a part."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            # Check if tolerance already exists
            cursor.execute("SELECT range_id FROM tolerance_ranges WHERE part_id = %s", (part_id,))
            existing = cursor.fetchone()
            
            if existing:
                # Update
                cursor.execute(
                    """UPDATE tolerance_ranges
                       SET brand_id = %s, mf_min = %s, mf_max = %s,
                           cec_tk_min = %s, cec_tk_max = %s,
                           rod_tk_min = %s, rod_tk_max = %s,
                           stroke_length_min = %s, stroke_length_max = %s,
                           closed_length_min = %s, closed_length_max = %s
                       WHERE part_id = %s""",
                    (brand_id, mf_min, mf_max, cec_min, cec_max, rod_min, rod_max,
                     stroke_min, stroke_max, closed_min, closed_max, part_id)
                )
                logger.info(f"Updated tolerance range for part_id {part_id}")
            else:
                # Insert
                cursor.execute(
                    """INSERT INTO tolerance_ranges
                       (part_id, brand_id, mf_min, mf_max,
                        cec_tk_min, cec_tk_max, rod_tk_min, rod_tk_max,
                        stroke_length_min, stroke_length_max,
                        closed_length_min, closed_length_max)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (part_id, brand_id, mf_min, mf_max, cec_min, cec_max, rod_min, rod_max,
                     stroke_min, stroke_max, closed_min, closed_max)
                )
                logger.info(f"Added tolerance range for part_id {part_id}")
            
            conn.commit()
            cursor.close()
            return True
    except Exception as e:
        logger.error(f"Error adding tolerance range for part {part_id}: {e}")
        return False


def get_all_ranges() -> list:
    """Get all tolerance ranges with part info."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT
                    tr.range_id,
                    tr.part_id,

                    p.part_no,

                    b.brand_name AS brand,

                    tr.mf_min AS MF_min,
                    tr.mf_max AS MF_max,

                    tr.cec_tk_min AS CEC_TK_min,
                    tr.cec_tk_max AS CEC_TK_max,

                    tr.rod_tk_min AS ROD_TK_min,
                    tr.rod_tk_max AS ROD_TK_max,

                    tr.stroke_length_min AS Stroke_min,
                    tr.stroke_length_max AS Stroke_max,

                    tr.closed_length_min AS Closed_min,
                    tr.closed_length_max AS Closed_max

                FROM tolerance_ranges tr
                JOIN part_numbers p
                    ON tr.part_id = p.part_id

                LEFT JOIN brands b
                    ON tr.brand_id = b.brand_id

                ORDER BY p.part_no
            """)
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting ranges: {e}")
        return []


def get_range_for_part(part_no: str) -> dict:
    """Get tolerance range for a specific part."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT
                    tr.range_id,
                    p.part_id,
                    p.part_no,

                    b.brand_name AS brand,

                    p.mounting_face_nominal,
                    p.cec_thickness_nominal,
                    p.rod_eye_thickness_nominal,
                    p.stroke_length_nominal,
                    p.closed_length_nominal,

                    tr.mf_min AS MF_min,
                    tr.mf_max AS MF_max,

                    tr.cec_tk_min AS CEC_TK_min,
                    tr.cec_tk_max AS CEC_TK_max,

                    tr.rod_tk_min AS ROD_TK_min,
                    tr.rod_tk_max AS ROD_TK_max,

                    tr.stroke_length_min,
                    tr.stroke_length_max,

                    tr.closed_length_min,
                    tr.closed_length_max
                FROM part_numbers p
                LEFT JOIN tolerance_ranges tr ON p.part_id = tr.part_id
                LEFT JOIN brands b ON p.brand_id = b.brand_id
                WHERE UPPER(p.part_no) = UPPER(%s)
                LIMIT 1
            """, (part_no,))
            result = cursor.fetchone()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting range for part {part_no}: {e}")
        return None


# =====================================================
# MEASUREMENTS
# =====================================================

def save_measurement(date: str, time_str: str, part_no: str,
                    cec_tk=None, rod_tk=None, mf=None,
                    stroke_length=None, closed_length=None,
                    status=None, operator=None) -> int:
    """
    Save a measurement. Returns measurement_id or -1 on error.
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            
            # Get part_id and brand_id
            cursor.execute(
                "SELECT part_id, brand_id FROM part_numbers WHERE UPPER(part_no) = UPPER(%s)",
                (part_no,)
            )
            result = cursor.fetchone()
            part_id = result[0] if result else None
            brand_id = result[1] if result else None
            
            # Insert measurement
            cursor.execute(
                """INSERT INTO measurements
                   (part_id, part_no, brand_id, measurement_date, measurement_time,
                    cec_tk, rod_tk, mounting_face, stroke_length, closed_length,
                    status, operator_name)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (part_id, part_no, brand_id, date, time_str, cec_tk, rod_tk, mf,
                 stroke_length, closed_length, status, operator)
            )
            conn.commit()
            
            measurement_id = cursor.lastrowid
            cursor.close()
            
            logger.info(f"Saved measurement {measurement_id}: {part_no}")
            return measurement_id
    except Exception as e:
        logger.error(f"Error saving measurement for {part_no}: {e}")
        return -1


def check_measurement(part_no: str, cec_tk=None, rod_tk=None, mf=None,
                     stroke_length=None, closed_length=None) -> str:
    """Check if measurement is within tolerance. Returns status."""
    try:
        rng = get_range_for_part(part_no)
        
        if not rng:
            return "PART NOT FOUND"
        
        status = "OK"
        
        # Check each dimension
        if cec_tk is not None and rng.get('cec_tk_min') and rng.get('cec_tk_max'):
            if not (rng['CEC_TK_min'] <= cec_tk <= rng['cec_tk_max']):
                status = "NOT OK"
        
        if rod_tk is not None and rng.get('rod_tk_min') and rng.get('rod_tk_max'):
            if not (rng['ROD_TK_min'] <= rod_tk <= rng['rod_tk_max']):
                status = "NOT OK"
        
        if mf is not None and rng.get('mf_min') and rng.get('mf_max'):
            if not (rng['MF_min'] <= mf <= rng['mf_max']):
                status = "NOT OK"
        
        if stroke_length is not None and rng.get('stroke_length_min') and rng.get('stroke_length_max'):
            if not (rng['stroke_length_min'] <= stroke_length <= rng['stroke_length_max']):
                status = "NOT OK"
        
        if closed_length is not None and rng.get('closed_length_min') and rng.get('closed_length_max'):
            if not (rng['closed_length_min'] <= closed_length <= rng['closed_length_max']):
                status = "NOT OK"
        
        return status
    except Exception as e:
        logger.error(f"Error checking measurement: {e}")
        return "ERROR"


def get_failure_detail(part_no: str, cec_tk=None, rod_tk=None, mf=None,
                       stroke_length=None, closed_length=None) -> list:
    """Get details of which measurements failed."""
    issues = []
    try:
        rng = get_range_for_part(part_no)
        
        if not rng:
            return ["Part not found in database"]
        
        if cec_tk is not None and rng.get('cec_tk_min') and rng.get('cec_tk_max'):
            if not (rng['CEC_TK_min'] <= cec_tk <= rng['cec_tk_max']):
                issues.append(f"CEC TK {cec_tk} outside {rng['CEC_TK_min']}-{rng['cec_tk_max']}")
        
        if rod_tk is not None and rng.get('rod_tk_min') and rng.get('rod_tk_max'):
            if not (rng['ROD_TK_min'] <= rod_tk <= rng['rod_tk_max']):
                issues.append(f"ROD TK {rod_tk} outside {rng['ROD_TK_min']}-{rng['rod_tk_max']}")
        
        if mf is not None and rng.get('mf_min') and rng.get('mf_max'):
            if not (rng['MF_min'] <= mf <= rng['mf_max']):
                issues.append(f"MF {mf} outside {rng['MF_min']}-{rng['mf_max']}")
        
        if stroke_length is not None and rng.get('stroke_length_min') and rng.get('stroke_length_max'):
            if not (rng['stroke_length_min'] <= stroke_length <= rng['stroke_length_max']):
                issues.append(f"Stroke Length {stroke_length} outside {rng['stroke_length_min']}-{rng['stroke_length_max']}")
        
        if closed_length is not None and rng.get('closed_length_min') and rng.get('closed_length_max'):
            if not (rng['closed_length_min'] <= closed_length <= rng['closed_length_max']):
                issues.append(f"Closed Length {closed_length} outside {rng['closed_length_min']}-{rng['closed_length_max']}")
        
        return issues if issues else ["Dimension out of tolerance"]
    except Exception as e:
        logger.error(f"Error getting failure detail: {e}")
        return ["Error checking measurement"]


def get_all_measurements() -> list:
    """Get all measurements."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT m.measurement_id, m.measurement_date, m.measurement_time,
                       m.part_no, b.brand_name AS brand , m.cec_tk AS CEC_TK,
                        m.rod_tk AS ROD_TK,
                        m.mounting_face AS MF,
                       m.stroke_length, m.closed_length, m.status, m.operator_name
                FROM measurements m
                LEFT JOIN brands b ON m.brand_id = b.brand_id
                ORDER BY m.measurement_timestamp DESC
            """)
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting measurements: {e}")
        return []


def get_measurements_by_part(part_no: str) -> list:
    """Get all measurements for a specific part."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT m.measurement_id, m.measurement_date, m.measurement_time,
                       m.part_no, b.brand_name AS brand , m.cec_tk AS CEC_TK,
                        m.rod_tk AS ROD_TK,
                        m.mounting_face AS MF,
                       m.stroke_length, m.closed_length, m.status, m.operator_name
                FROM measurements m
                LEFT JOIN brands b ON m.brand_id = b.brand_id
                WHERE UPPER(m.part_no) = UPPER(%s)
                ORDER BY m.measurement_timestamp DESC
            """, (part_no,))
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting measurements for part {part_no}: {e}")
        return []


def get_measurements_by_brand(brand_name: str) -> list:
    """Get all measurements for a specific brand."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT m.measurement_id, m.measurement_date, m.measurement_time,
                       m.part_no, b.brand_name, m.cec_tk, m.rod_tk, m.mounting_face,
                       m.stroke_length, m.closed_length, m.status, m.operator_name
                FROM measurements m
                LEFT JOIN brands b ON m.brand_id = b.brand_id
                WHERE UPPER(b.brand_name) = UPPER(%s)
                ORDER BY m.measurement_timestamp DESC
            """, (brand_name,))
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting measurements for brand {brand_name}: {e}")
        return []


def get_measurements_by_date(start_date: str, end_date: str) -> list:
    """Get measurements for a date range."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT m.measurement_id, m.measurement_date, m.measurement_time,
                       m.part_no, b.brand_name, m.cec_tk, m.rod_tk, m.mounting_face,
                       m.stroke_length, m.closed_length, m.status, m.operator_name
                FROM measurements m
                LEFT JOIN brands b ON m.brand_id = b.brand_id
                WHERE m.measurement_date BETWEEN %s AND %s
                ORDER BY m.measurement_timestamp DESC
            """, (start_date, end_date))
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting measurements by date: {e}")
        return []


def get_report_summary() -> dict:
    """Get overall report summary."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            
            # Overall stats
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'OK' THEN 1 ELSE 0 END) as passed,
                    SUM(CASE WHEN status = 'NOT OK' THEN 1 ELSE 0 END) as failed,
                    SUM(CASE WHEN status = 'PART NOT FOUND' THEN 1 ELSE 0 END) as not_found
                FROM measurements
            """)
            overall = cursor.fetchone()
            
            total = overall['total'] or 0
            passed = overall['passed'] or 0
            failed = overall['failed'] or 0
            not_found = overall['not_found'] or 0
            yield_pct = (passed / total * 100) if total > 0 else 0
            
            # Part stats
            cursor.execute("""
                SELECT 
                    p.part_no, b.brand_name,
                    SUM(CASE WHEN m.status = 'OK' THEN 1 ELSE 0 END) as pass_count,
                    SUM(CASE WHEN m.status = 'NOT OK' THEN 1 ELSE 0 END) as fail_count
                FROM part_numbers p
                LEFT JOIN measurements m ON p.part_id = m.part_id
                LEFT JOIN brands b ON p.brand_id = b.brand_id
                GROUP BY p.part_id
                ORDER BY p.part_no
            """)
            part_results = cursor.fetchall()
            
            part_stats = {}
            for row in part_results:
                if row['part_no']:
                    part_stats[row['part_no']] = {
                        'brand': row['brand_name'],
                        'pass': row['pass_count'] or 0,
                        'fail': row['fail_count'] or 0
                    }
            
            # Brand stats
            cursor.execute("""
                SELECT 
                    b.brand_name AS brand,
                    SUM(CASE WHEN m.status = 'OK' THEN 1 ELSE 0 END) as pass_count,
                    SUM(CASE WHEN m.status = 'NOT OK' THEN 1 ELSE 0 END) as fail_count
                FROM brands b
                LEFT JOIN measurements m ON b.brand_id = m.brand_id
                GROUP BY b.brand_id
                ORDER BY b.brand_name
            """)
            brand_results = cursor.fetchall()
            
            brand_stats = {}
            for row in brand_results:
                if row['brand_name']:
                    brand_stats[row['brand_name']] = {
                        'pass': row['pass_count'] or 0,
                        'fail': row['fail_count'] or 0
                    }
            
            # Trend data (last 50)
            cursor.execute("""
                SELECT m.measurement_date, m.part_no, m.cec_tk, m.rod_tk, m.mounting_face,
                       m.stroke_length, m.closed_length, m.status
                FROM measurements m
                ORDER BY m.measurement_timestamp DESC
                LIMIT 50
            """)
            trend_results = cursor.fetchall()
            trend = list(reversed(trend_results))  # Reverse to chronological order
            
            cursor.close()
            
            return {
                'total': total,
                'passed': passed,
                'failed': failed,
                'not_found': not_found,
                'yield_pct': round(yield_pct, 2),
                'part_stats': part_stats,
                'brand_stats': brand_stats,
                'trend': trend
            }
    except Exception as e:
        logger.error(f"Error getting report summary: {e}")
        return {
            'total': 0, 'passed': 0, 'failed': 0, 'not_found': 0, 
            'yield_pct': 0, 'part_stats': {}, 'brand_stats': {}, 'trend': []
        }


def get_statistics_by_date(days: int = 30) -> list:
    """Get statistics for the last N days."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT 
                    m.measurement_date,
                    SUM(CASE WHEN m.status = 'OK' THEN 1 ELSE 0 END) as ok_count,
                    SUM(CASE WHEN m.status = 'NOT OK' THEN 1 ELSE 0 END) as fail_count,
                    COUNT(*) as total
                FROM measurements m
                WHERE m.measurement_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY m.measurement_date
                ORDER BY m.measurement_date DESC
            """, (days,))
            result = cursor.fetchall()
            cursor.close()
            return result
    except Exception as e:
        logger.error(f"Error getting statistics by date: {e}")
        return []