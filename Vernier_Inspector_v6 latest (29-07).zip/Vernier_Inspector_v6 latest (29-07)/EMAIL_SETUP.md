# Email Configuration Guide - MCP Vernier Inspector

## Overview
The auto-email feature sends daily inspection reports to Outlook with:
- **OK parts count**
- **Not OK parts count**
- **Pending parts count and reasons**

## Prerequisites
- Windows operating system (uses Outlook COM interface)
- Microsoft Outlook installed and configured
- Python `pywin32` library (added to requirements.txt)

## Setup Instructions

### 1. Install Required Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- `pywin32` - For Outlook integration
- `schedule` - For scheduling daily emails
- `python-dotenv` - For environment configuration

### 2. Configure Email Settings

Edit `config.py` and update the email section:

```python
# ======= EMAIL CONFIGURATION ======================================─
EMAIL_ENABLED       = True  # Set to True to enable email reports
EMAIL_SCHEDULE_HOUR = 17    # Hour to send report (24-hour format, e.g., 17 = 5 PM)
EMAIL_SCHEDULE_MIN  = 0     # Minutes (e.g., 0 for 5:00 PM)

# Outlook/Recipient Configuration
EMAIL_RECIPIENT     = "your-email@company.com"  # Email recipient
EMAIL_CC_LIST       = ["manager@company.com"]   # CC recipients (optional)
COMPANY_NAME        = "MCP"                      # Company name in email
INSPECTION_MANAGER  = "Inspection Manager"       # Title in email
```

### 3. Environment Variables (Optional)

Instead of editing `config.py`, you can use environment variables:

```bash
# Windows Command Prompt
set EMAIL_ENABLED=True
set EMAIL_SCHEDULE_HOUR=17
set EMAIL_SCHEDULE_MIN=0
set EMAIL_RECIPIENT=your-email@company.com
set EMAIL_CC=manager1@company.com,manager2@company.com
set COMPANY_NAME=MCP
set INSPECTION_MGR=Inspection Manager
```

Or create a `.env` file:

```env
EMAIL_ENABLED=True
EMAIL_SCHEDULE_HOUR=17
EMAIL_SCHEDULE_MIN=0
EMAIL_RECIPIENT=your-email@company.com
EMAIL_CC=manager1@company.com,manager2@company.com
COMPANY_NAME=MCP
INSPECTION_MGR=Inspection Manager
```

### 4. Test Email Configuration

Run the Flask app and use the API endpoint to test:

```bash
# Start the application
python app.py
```

Then in your browser or using curl/Postman:

```
POST http://localhost:5000/api/email/test
```

**Note:** You must be logged in as an admin user.

### 5. Manual Trigger

To manually send today's report:

```
POST http://localhost:5000/api/email/send_report
```

### 6. Check Scheduler Status

To see the scheduler status:

```
GET http://localhost:5000/api/email/status
```

## Email Format

The email includes:
- **Header** with company name and timestamp
- **Summary cards** showing:
  - ✓ OK parts (count & percentage)
  - ✗ Not OK parts (count & percentage)
  - ⏳ Pending parts (count & percentage)
  - ∑ Total inspections
- **Detailed statistics table**
- **Failure reasons** (if any)
- **Footer** with automated report disclaimer

## Troubleshooting

### Issue: "The system cannot find the file specified"
**Solution:** Make sure Outlook is installed and configured on your Windows machine.

### Issue: Email not sent at scheduled time
**Solution:** 
- Check if `EMAIL_ENABLED=True` in config.py
- Verify the schedule time format (24-hour format)
- Check Flask app console for scheduler messages

### Issue: Permission denied error
**Solution:** Make sure you're logged in as an admin user when calling email APIs.

### Issue: Outlook not found
**Solution:** 
- Verify Outlook is installed: `Control Panel → Programs → Programs and Features`
- Ensure Outlook is running at the time email is scheduled to send
- Alternative: Configure Windows Mail if Outlook is not available

## Database Requirements

The email feature requires:
- **MySQL database** with a `measurements` table
- Columns: `status`, `reason`, `inspection_date`
- Supported status values: 'ok', 'not_ok', 'fail', 'pending'

### SQL Table Structure Example:

```sql
CREATE TABLE measurements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    date DATE,
    time TIME,
    part_no VARCHAR(50),
    brand VARCHAR(50),
    CEC_TK DECIMAL(10,3),
    ROD_TK DECIMAL(10,3),
    MF DECIMAL(10,3),
    status VARCHAR(20),
    reason VARCHAR(255),
    inspection_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Daily Report Content

**Example Report:**

Subject: `MCP Inspection Report - 2026-07-27`

Content:
- Date: July 27, 2026
- Total Inspections: 45
- OK Parts: 42 (93.3%)
- Not OK Parts: 2 (4.4%)
- Pending: 1 (2.2%)
- Failure Reasons: "CEC TK out of range", "MF dimension exceeded"

## API Endpoints

### Send Daily Report (Manual Trigger)
```
POST /api/email/send_report
Authorization: Admin required
Response: { "success": true, "message": "Report sent successfully" }
```

### Send Test Email
```
POST /api/email/test
Authorization: Admin required
Response: { "success": true, "message": "Test email sent successfully" }
```

### Check Scheduler Status
```
GET /api/email/status
Authorization: Admin required
Response: {
    "enabled": true,
    "scheduler": {
        "enabled": true,
        "running": true,
        "schedule_time": "17:00",
        "jobs": 1
    }
}
```

## Disabling Email

To disable automatic emails:
1. Set `EMAIL_ENABLED = False` in `config.py`, OR
2. Set environment variable: `set EMAIL_ENABLED=False`

The scheduler will not start if disabled.

## Notes

- Emails are sent using your Windows Outlook account
- The scheduler runs in a background thread
- Reports are generated from today's inspection data only
- Failed emails are logged but don't interrupt the application
- Email times are in 24-hour format (0-23 for hours)

## Support

For issues:
1. Check Flask console for error messages
2. Verify Outlook is installed and working
3. Test with `/api/email/test` endpoint first
4. Check Windows Event Viewer for system-level errors
5. Review application logs for scheduler messages
