

# Login credentials:

| User | Username | Password | Access |
|------|----------|----------|--------|
| Admin | admin | admin123 | Full access, all pages |
| Operator | operator | user123 | Inspect + History |