# =====================================================
# MAIN APPLICATION  —  MCP Vernier Inspector v2.0
# MySQL Database Integration with Cylinder Testing
# =====================================================
import csv
import io
from datetime import datetime

from flask import (Flask, Response, jsonify, redirect,
                   render_template, request, session, url_for)

#  Hardware: Mitutoyo vernier 
try:
    from bluetooth_reader import (
        connect         as mitutoyo_connect,
        get_channel_progress,
        get_connection_status,
        get_last_raw,
        get_pending_channel,
        list_available_ports,
        read_measurement,
        reset_channel_buffer,
    )
    _MITUTOYO_OK = True
except Exception as _e:
    print(f"[App] bluetooth_reader import failed: {_e}")
    _MITUTOYO_OK = False
    def read_measurement():         return None
    def get_connection_status():    return "disconnected"
    def get_pending_channel():      return "CEC_TK"
    def get_channel_progress():     return {"CEC_TK": None, "ROD_TK": None, "MF": None}
    def reset_channel_buffer():     pass
    def list_available_ports():     return []
    def mitutoyo_connect(p=None):   return False
    def get_last_raw():             return ""

#  Hardware: Honeywell 1470G scanner 
try:
    from scanner_reader import (
        get_latest_scan,
        get_scanner_status,
        list_scanner_ports,
        push_hid_scan,
        start_scanner,
    )
    _SCANNER_OK = True
except Exception as _e:
    print(f"[App] scanner_reader import failed: {_e}")
    _SCANNER_OK = False
    def start_scanner():            pass
    def get_latest_scan():          return None
    def get_scanner_status():       return "hid"
    def push_hid_scan(b):           pass
    def list_scanner_ports():       return []

#  Data layer - MySQL
from db_handler import (
    check_measurement,
    get_all_brands,
    get_all_measurements,
    get_all_ranges,
    get_failure_detail,
    get_nominal_data,
    get_range_for_part,
    get_report_summary,
    get_measurements_by_part,
    get_measurements_by_brand,
    get_measurements_by_date,
    get_statistics_by_date,
    save_measurement,
    add_part_number,
    add_tolerance_range,
    add_brand,
    initialize_database,
    test_connection,
)

from config import (
    ADMIN_PASSWORD, ADMIN_USERNAME,
    AUTO_SAVE, MITUTOYO_PORT,
    OPERATOR_PASSWORD, OPERATOR_USERNAME,
    SCANNER_MODE, SCANNER_PORT,
    SECRET_KEY, UNIT, CYLINDER_ENABLED, DB_MODE
)

# FLASK APP
app = Flask(__name__)
app.secret_key = SECRET_KEY

# Initialize database
print("[App] Initializing database...")
if test_connection():
    print("[App] Database connection successful")
    if initialize_database():
        print("[App] Database ready")
    else:
        print("[App] WARNING: Please run database.sql to initialize tables")
else:
    print("[App] ERROR: Cannot connect to database")

start_scanner()


# AUTH HELPERS
def logged_in() -> bool:
    return "user" in session

def is_admin() -> bool:
    return session.get("role") == "admin"


# LOGIN / LOGOUT
@app.route("/", methods=["GET", "POST"])
def login():
    if logged_in():
        return redirect(url_for("dashboard"))
    error = None
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if u == ADMIN_USERNAME and p == ADMIN_PASSWORD:
            session.update({"user": u, "role": "admin"})
            return redirect(url_for("dashboard"))
        if u == OPERATOR_USERNAME and p == OPERATOR_PASSWORD:
            session.update({"user": u, "role": "operator"})
            return redirect(url_for("dashboard"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# DASHBOARD  &  SETUP
@app.route("/dashboard")
def dashboard():
    if not logged_in():
        return redirect(url_for("login"))
    return render_template(
        "dashboard.html",
        username         = session["user"],
        role             = session.get("role", "operator"),
        unit             = UNIT,
        mitutoyo_port    = MITUTOYO_PORT,
        scanner_mode     = SCANNER_MODE,
        auto_save        = AUTO_SAVE,
        cylinder_enabled = CYLINDER_ENABLED,
    )


@app.route("/setup")
def setup():
    if not logged_in():
        return redirect(url_for("login"))
    if not is_admin():
        return redirect(url_for("dashboard"))
    
    return render_template(
        "setup.html",
        mitutoyo_ports = list_available_ports(),
        scanner_ports  = list_scanner_ports(),
        config = {
            "mitutoyo_port": MITUTOYO_PORT,
            "scanner_mode":  SCANNER_MODE,
            "scanner_port":  SCANNER_PORT,
        },
        cylinder_enabled = CYLINDER_ENABLED,
    )


# API — DATABASE MANAGEMENT
@app.route("/api/db/brands", methods=["GET", "POST"])
def api_db_brands():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    
    if request.method == "POST":
        if not is_admin():
            return jsonify({"error": "Admin only"}), 403
        brand_name = request.get_json(force=True).get("brand_name", "").strip()
        if not brand_name:
            return jsonify({"error": "brand_name required"}), 400
        if add_brand(brand_name):
            return jsonify({"ok": True, "brand": brand_name})
        return jsonify({"error": "Failed to add brand"}), 500
    
    return jsonify(get_all_brands())


@app.route("/api/db/parts", methods=["GET", "POST"])
def api_db_parts():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    
    if request.method == "POST":
        if not is_admin():
            return jsonify({"error": "Admin only"}), 403
        body = request.get_json(force=True)
        part_id = add_part_number(
            part_no=body.get("part_no", "").upper(),
            brand_name=body.get("brand_name", ""),
            description=body.get("description", ""),
            mf_nom=float(body.get("mf_nominal", 0)) or None,
            cec_nom=float(body.get("cec_nominal", 0)) or None,
            rod_nom=float(body.get("rod_nominal", 0)) or None,
            stroke_nom=float(body.get("stroke_nominal", 0)) or None,
            closed_nom=float(body.get("closed_nominal", 0)) or None,
        )
        if part_id > 0:
            return jsonify({"ok": True, "part_id": part_id})
        return jsonify({"error": "Failed to add part"}), 500
    
    return jsonify(get_nominal_data())


@app.route("/api/db/tolerance", methods=["POST"])
def api_db_tolerance():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    if not is_admin():
        return jsonify({"error": "Admin only"}), 403
    
    body = request.get_json(force=True)
    if add_tolerance_range(
        part_id=int(body.get("part_id")),
        brand_id=body.get("brand_id"),
        mf_min=float(body.get("mf_min")) or None if body.get("mf_min") else None,
        mf_max=float(body.get("mf_max")) or None if body.get("mf_max") else None,
        cec_min=float(body.get("cec_min")) or None if body.get("cec_min") else None,
        cec_max=float(body.get("cec_max")) or None if body.get("cec_max") else None,
        rod_min=float(body.get("rod_min")) or None if body.get("rod_min") else None,
        rod_max=float(body.get("rod_max")) or None if body.get("rod_max") else None,
        stroke_min=float(body.get("stroke_min")) or None if body.get("stroke_min") else None,
        stroke_max=float(body.get("stroke_max")) or None if body.get("stroke_max") else None,
        closed_min=float(body.get("closed_min")) or None if body.get("closed_min") else None,
        closed_max=float(body.get("closed_max")) or None if body.get("closed_max") else None,
    ):
        return jsonify({"ok": True})
    return jsonify({"error": "Failed to set tolerance"}), 500


# API — DEVICE STATUS
@app.route("/api/device_status")
def api_device_status():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify({
        "mitutoyo":        get_connection_status(),
        "scanner":         get_scanner_status(),
        "pending_channel": get_pending_channel(),
        "progress":        get_channel_progress(),
        "mitutoyo_ports":  list_available_ports(),
        "scanner_ports":   list_scanner_ports(),
        "last_raw":        get_last_raw(),
    })


# API — LIVE MEASUREMENT  (poll every 600 ms)
@app.route("/api/live_measurement")
def api_live_measurement():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401

    data    = read_measurement()    # dict or None
    pending = get_pending_channel()
    prog    = get_channel_progress()

    if data is None:
        # No complete measurement yet — return progress state
        return jsonify({
            "complete":        False,
            "pending_channel": pending,
            "progress":        prog,
            "mitutoyo_status": get_connection_status(),
        })

    # Complete measurement received
    part_no = session.get("current_part_no", "")
    status  = None
    issues  = []
    
    # Handle stroke_length and closed_length if available
    stroke_length = data.get("STROKE_LENGTH")
    closed_length = data.get("CLOSED_LENGTH")
    
    if part_no:
        status = check_measurement(
            part_no, 
            data["CEC_TK"], 
            data["ROD_TK"], 
            data["MF"],
            stroke_length=stroke_length,
            closed_length=closed_length
        )
        if status == "NOT OK":
            issues = get_failure_detail(
                part_no, 
                data["CEC_TK"], 
                data["ROD_TK"], 
                data["MF"],
                stroke_length=stroke_length,
                closed_length=closed_length
            )

    result = {
        "complete":        True,
        "CEC_TK":          data["CEC_TK"],
        "ROD_TK":          data["ROD_TK"],
        "MF":              data["MF"],
        "STROKE_LENGTH":   stroke_length,
        "CLOSED_LENGTH":   closed_length,
        "mitutoyo_status": get_connection_status(),
        "status":          status,
        "issues":          issues,
    }

    # Auto-save if configured
    if AUTO_SAVE and part_no and status:
        now = datetime.now()
        save_measurement(
            now.strftime("%Y-%m-%d"), 
            now.strftime("%H:%M:%S"),
            part_no, 
            data["CEC_TK"], 
            data["ROD_TK"], 
            data["MF"],
            stroke_length=stroke_length,
            closed_length=closed_length,
            status=status,
            operator=session.get("user", "unknown")
        )
        session.pop("current_part_no", None)
        reset_channel_buffer()
        result["auto_saved"] = True

    return jsonify(result)


@app.route("/api/reset_measurement", methods=["POST"])
def api_reset_measurement():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    reset_channel_buffer()
    return jsonify({"ok": True})


# API — SCANNER
@app.route("/api/hid_scan", methods=["POST"])
def api_hid_scan():
    """Called by the browser when the HID scanner sends a barcode."""
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    barcode = str(request.get_json(force=True).get("barcode", "")).strip().upper()
    if not barcode:
        return jsonify({"error": "empty barcode"}), 400

    session["current_part_no"] = barcode
    rng = get_range_for_part(barcode)
    return jsonify({
        "part_no": barcode,
        "found":   rng is not None,
        "range":   rng,
    })


@app.route("/api/latest_scan")
def api_latest_scan():
    """Poll endpoint for serial-mode scanner."""
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    barcode = get_latest_scan()
    if barcode:
        barcode = barcode.upper()
        session["current_part_no"] = barcode
        rng = get_range_for_part(barcode)
        return jsonify({
            "scanned": True,
            "part_no": barcode,
            "found":   rng is not None,
            "range":   rng,
        })
    return jsonify({"scanned": False})


@app.route("/api/set_part_no", methods=["POST"])
def api_set_part_no():
    """Manual part number entry from the dashboard input field."""
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    part_no = str(request.get_json(force=True).get("part_no", "")).strip().upper()
    if not part_no:
        return jsonify({"error": "part_no required"}), 400
    session["current_part_no"] = part_no
    rng = get_range_for_part(part_no)
    return jsonify({"part_no": part_no, "found": rng is not None, "range": rng})


@app.route("/api/current_part")
def api_current_part():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    part_no = session.get("current_part_no", "")
    rng = get_range_for_part(part_no) if part_no else None
    return jsonify({"part_no": part_no, "range": rng})


# API — SAVE MEASUREMENT
@app.route("/api/save_measurement", methods=["POST"])
def api_save_measurement():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    body    = request.get_json(force=True)
    part_no = str(body.get("part_no", "")).strip().upper()
    cec_tk  = float(body.get("CEC_TK", 0))
    rod_tk  = float(body.get("ROD_TK", 0))
    mf      = float(body.get("MF", 0))
    stroke_length = float(body.get("STROKE_LENGTH", 0)) if body.get("STROKE_LENGTH") else None
    closed_length = float(body.get("CLOSED_LENGTH", 0)) if body.get("CLOSED_LENGTH") else None
    
    if not part_no:
        return jsonify({"error": "part_no required"}), 400

    status = check_measurement(
        part_no, cec_tk, rod_tk, mf,
        stroke_length=stroke_length,
        closed_length=closed_length
    )
    issues = get_failure_detail(
        part_no, cec_tk, rod_tk, mf,
        stroke_length=stroke_length,
        closed_length=closed_length
    ) if status == "NOT OK" else []

    now = datetime.now()
    save_measurement(
        now.strftime("%Y-%m-%d"), 
        now.strftime("%H:%M:%S"),
        part_no, cec_tk, rod_tk, mf,
        stroke_length=stroke_length,
        closed_length=closed_length,
        status=status,
        operator=session.get("user", "unknown")
    )
    session.pop("current_part_no", None)
    reset_channel_buffer()
    return jsonify({"status": status, "issues": issues})


# API — DATA READS
@app.route("/api/output_data")
def api_output_data():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_all_measurements())


@app.route("/api/ranges")
def api_ranges():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_all_ranges())


@app.route("/api/part_catalog")
def api_part_catalog():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_nominal_data())


@app.route("/api/brands")
def api_brands():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_all_brands())


@app.route("/api/part_lookup/<path:part_no>")
def api_part_lookup(part_no):
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    rng = get_range_for_part(part_no)
    if rng is None:
        return jsonify({"found": False}), 404
    return jsonify({"found": True, "range": rng})


@app.route("/api/part_history/<path:part_no>")
def api_part_history(part_no):
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    measurements = get_measurements_by_part(part_no.upper())
    return jsonify(measurements)


@app.route("/api/brand_history/<path:brand_name>")
def api_brand_history(brand_name):
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    measurements = get_measurements_by_brand(brand_name)
    return jsonify(measurements)


@app.route("/api/report_summary")
def api_report_summary():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_report_summary())


@app.route("/api/statistics/date_range", methods=["POST"])
def api_statistics_date_range():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    body = request.get_json(force=True)
    start_date = body.get("start_date", "")
    end_date = body.get("end_date", "")
    measurements = get_measurements_by_date(start_date, end_date)
    return jsonify(measurements)


@app.route("/api/statistics/trend/<int:days>")
def api_statistics_trend(days=30):
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    stats = get_statistics_by_date(days)
    return jsonify(stats)


# API — SETUP
@app.route("/api/setup/connect_mitutoyo", methods=["POST"])
def api_setup_connect_mitutoyo():
    if not logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    port = request.get_json(force=True).get("port", MITUTOYO_PORT)
    ok   = mitutoyo_connect(port)
    return jsonify({"connected": ok, "status": get_connection_status()})


# EXPORT — CSV
@app.route("/export/csv")
def export_csv():
    if not logged_in():
        return redirect(url_for("login"))
    rows = get_all_measurements()
    buf  = io.StringIO()
    w    = csv.writer(buf)
    
    headers = [
        "Date", "Time", "Part No", "Brand",
        f"CEC TK ({UNIT})", f"ROD TK ({UNIT})", f"MF ({UNIT})",
    ]
    if CYLINDER_ENABLED:
        headers.extend([f"Stroke Length ({UNIT})", f"Closed Length ({UNIT})"])
    headers.append("Status")
    
    w.writerow(headers)
    
    for m in rows:
        row = [
            m.get("measurement_date", ""),
            m.get("measurement_time", ""),
            m.get("part_no", ""),
            m.get("brand_name", ""),
            m.get("cec_tk", ""),
            m.get("rod_tk", ""),
            m.get("mounting_face", ""),
        ]
        if CYLINDER_ENABLED:
            row.extend([
                m.get("stroke_length", ""),
                m.get("closed_length", ""),
            ])
        row.append(m.get("status", ""))
        w.writerow(row)
    
    fname = f"MCP_inspection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        buf.getvalue(),
        mimetype = "text/csv",
        headers  = {"Content-Disposition": f"attachment; filename={fname}"},
    )


# EXPORT — JSON
@app.route("/export/json")
def export_json():
    if not logged_in():
        return redirect(url_for("login"))
    measurements = get_all_measurements()
    fname = f"MCP_inspection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    return Response(
        jsonify(measurements).get_json(),
        mimetype = "application/json",
        headers  = {"Content-Disposition": f"attachment; filename={fname}"},
    )


# Run
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
