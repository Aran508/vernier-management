# =====================================================
# CONFIGURATION  —  MCP Vernier Inspector v2.0
# =====================================================
# Edit this file to match your hardware.
# All values can also be set as environment variables.

import os

# ======= Mitutoyo U-WAVE / SPC Vernier =================
# MITUTOYO_MODE = "serial" — U-WAVE-T/TM/TC + U-WAVE-R USB receiver.
#                 Proprietary 2.4GHz protocol, shows up as a real COM port.
# MITUTOYO_MODE = "hid"    — U-WAVE-TCB (Bluetooth LE). BLE devices never
#                 get a COM port; Mitutoyo's U-WAVEPAK-BW / USB-ITPAK
#                 software types each reading as keystrokes instead
#                 (keyboard-wedge, same idea as the barcode scanner).
#                 The dashboard captures those keystrokes in the browser.
MITUTOYO_MODE     = os.getenv("MITUTOYO_MODE", "hid")
# Windows: "COM3"  |  Linux: "/dev/ttyUSB0"  (only used when MODE = "serial")
MITUTOYO_PORT     = os.getenv("MITUTOYO_PORT",  "COM3")
MITUTOYO_BAUD     = int(os.getenv("MITUTOYO_BAUD", "9600"))
MITUTOYO_BYTESIZE = 8      # 8 data bits  (Mitutoyo SPC default)
MITUTOYO_PARITY   = "N"    # No parity    (Mitutoyo SPC default)
MITUTOYO_STOP     = 1      # 1 stop bit   (Mitutoyo SPC default)
MITUTOYO_TIMEOUT  = 1.0    # serial read timeout in seconds

# ======= Channel order ============================================
# The vernier sends one value per DATA-button press.
# List the 3 channels in the order the operator will press DATA.
CHANNEL_ORDER = ["CEC_TK", "ROD_TK", "MF"]

# ======= Honeywell Voyager XP 1470G Scanner =====================──
# SCANNER_MODE = "usb_hid"   — plug & play, no config (factory default)
# SCANNER_MODE = "serial"    — virtual COM after EZConfig programming
SCANNER_MODE  = os.getenv("SCANNER_MODE",  "usb_hid")
SCANNER_PORT  = os.getenv("SCANNER_PORT",  "COM3")
SCANNER_BAUD  = int(os.getenv("SCANNER_BAUD", "9600"))

# ======= Data Files (Legacy Excel) =============================─
DATA_FILE  = os.getenv("DATA_FILE", "data/MCPVERNIERDATA.xlsx")
RANGE_FILE = DATA_FILE   # Same workbook — sheet "MCP MIN&MAX"

# ======= MySQL Database Configuration ======================──
DB_HOST     = os.getenv("DB_HOST",     "127.0.0.1")
DB_PORT     = int(os.getenv("DB_PORT", "3306"))
DB_USER     = os.getenv("DB_USER",     "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Root@123")
DB_NAME     = os.getenv("DB_NAME",     "mcp_vernier_db")

# Database mode: 'mysql' (recommended) or 'excel' (legacy)
DB_MODE = os.getenv("DB_MODE", "mysql")

# ======= Flask / Auth ============================================─
SECRET_KEY         = os.getenv("SECRET_KEY",   "mcp_vernier_change_in_prod")
ADMIN_USERNAME     = os.getenv("ADMIN_USER",   "admin")
ADMIN_PASSWORD     = os.getenv("ADMIN_PASS",   "admin123")
OPERATOR_USERNAME  = os.getenv("OP_USER",      "operator")
OPERATOR_PASSWORD  = os.getenv("OP_PASS",      "user123")

# ======= Behaviour ===================================================─
UNIT      = "mm"    # measurement unit label (display only)
AUTO_SAVE = False   # True = save automatically when all 3 channels complete
CYLINDER_ENABLED = True  # Enable cylinder testing (stroke & closed length)

# ======= EMAIL CONFIGURATION ======================================─
# Enable daily email reports
EMAIL_ENABLED       = os.getenv("EMAIL_ENABLED", "True").lower() == "true"
EMAIL_SCHEDULE_HOUR = int(os.getenv("EMAIL_SCHEDULE_HOUR", "17"))  # 5 PM (24-hour format)
EMAIL_SCHEDULE_MIN  = int(os.getenv("EMAIL_SCHEDULE_MIN", "0"))    # Minutes

# Outlook/Recipient Configuration
EMAIL_RECIPIENT     = os.getenv("EMAIL_RECIPIENT", "your-email@company.com")  # Where to send reports
EMAIL_CC_LIST       = os.getenv("EMAIL_CC", "").split(",") if os.getenv("EMAIL_CC") else []
COMPANY_NAME        = os.getenv("COMPANY_NAME", "MCP")
INSPECTION_MANAGER  = os.getenv("INSPECTION_MGR", "Inspection Manager")
