# =====================================================
# MITUTOYO U-WAVE / SPC SERIAL READER
# =====================================================
#
# Hardware path:
#   Mitutoyo instrument (vernier/micrometer)
#       → Mitutoyo U-WAVE-T transmitter  (clips to SPC port)
#       → Mitutoyo U-WAVE-R USB receiver (plugs into PC)
#       → Virtual COM port (CP210x / CH340 driver)
#       → This module
#
# SPC packet format (Mitutoyo standard, 13 bytes):
#   Byte  0   : STX or device flags
#   Bytes 1-4 : sign + 4-digit integer part (e.g. b'0011')
#   Byte  5   : decimal point position (0x02 = 2 dp → divide by 100)
#   Bytes 6-12: remaining digits, polarity, checksum
#
#   Value = signed integer × 10^(-decimal_pos)
#
#   Example (119.5 mm):
#   b'\x01\x30\x31\x31\x39\x35\x30\x30\x30\x02\x2b\x0d\x0a'
#
# U-WAVE-R can also be configured to send plain ASCII:
#   b'+011950\r\n'   (value × 100, no decimal point)
#   b'+011.950\r\n'  (value with decimal, newer firmware)
#
# This module handles BOTH formats automatically.
#
# Channel workflow:
#   Operator presses DATA → CEC_TK arrives
#   Operator presses DATA → ROD_TK arrives
#   Operator presses DATA → MF arrives
#   All 3 done → read_measurement() returns {"CEC_TK":x,"ROD_TK":y,"MF":z}
# =====================================================

import re
import threading
import time

import serial
import serial.tools.list_ports

from config import (
    MITUTOYO_PORT, MITUTOYO_BAUD,
    MITUTOYO_BYTESIZE, MITUTOYO_PARITY,
    MITUTOYO_STOP, MITUTOYO_TIMEOUT,
    CHANNEL_ORDER,
)

# MODULE STATE  (all protected by _lock)
_ser          = None
_lock         = threading.Lock()
_channel_buf  = {}          # {channel_name: float}  e.g. {"CEC_TK": 119.5}
_read_buf     = b""         # incomplete packet accumulator
_last_raw_hex = ""          # last raw bytes as hex string, for diagnostics
_status       = "disconnected"


# CONNECTION
def connect(port: str = None) -> bool:
    """Open serial connection to Mitutoyo U-WAVE-R receiver."""
    global _ser, _status
    preferred = port or MITUTOYO_PORT
    candidates = []
    seen = set()

    if preferred:
        candidates.append(preferred)
        seen.add(preferred)

    for p in serial.tools.list_ports.comports():
        if p.device not in seen:
            candidates.append(p.device)
            seen.add(p.device)

    last_error = None
    for target in candidates:
        try:
            with _lock:
                if _ser and _ser.is_open:
                    _ser.close()
                _ser = serial.Serial(
                    port      = target,
                    baudrate  = MITUTOYO_BAUD,
                    bytesize  = MITUTOYO_BYTESIZE,
                    parity    = MITUTOYO_PARITY,
                    stopbits  = MITUTOYO_STOP,
                    timeout   = MITUTOYO_TIMEOUT,
                )
                _status = "connected"
            print(f"[Mitutoyo] Connected: {target} @ {MITUTOYO_BAUD}baud 8N1")
            return True
        except serial.SerialException as exc:
            last_error = exc
            print(f"[Mitutoyo] Cannot open {target}: {exc}")

    _ser = None
    _status = "disconnected"
    if last_error:
        print(f"[Mitutoyo] Connection failed. Last error: {last_error}")
    return False


def disconnect():
    global _ser, _status
    with _lock:
        try:
            if _ser and _ser.is_open:
                _ser.close()
        except Exception:
            pass
        _ser    = None
        _status = "disconnected"


def get_connection_status() -> str:
    """Return 'connected' or 'disconnected'."""
    with _lock:
        return "connected" if (_ser and _ser.is_open) else "disconnected"


def list_available_ports() -> list[dict]:
    """
    Return all serial ports detected on this PC.
    Each entry: {"port": "COM3", "desc": "CP210x ...", "hwid": "USB\\VID..."}
    """
    return [
        {"port": p.device, "desc": p.description, "hwid": p.hwid or ""}
        for p in serial.tools.list_ports.comports()
    ]


# SPC PACKET PARSER
def _parse_spc_packet(raw: bytes) -> float | None:
    """
    Parse a Mitutoyo SPC / U-WAVE packet into a float value (mm).

    Handles three real-world formats:

    FORMAT 1 — 13-byte binary SPC (most common with U-WAVE-R):
      Byte 0      : flags / STX  (ignore)
      Bytes 1–6   : ASCII digits with sign, e.g. b' 11950' or b'+11950'
      Byte 7      : decimal digits count (0x02 → 2 dp → divide by 100)
      Bytes 8–12  : polarity byte (b'+' or b'-'), CR, LF, etc.
      Value = int(bytes1-6) × 10^(-byte7)  ×  sign

    FORMAT 2 — plain ASCII with decimal (newer firmware or simple mode):
      b'+011.950\r\n'  → 11.950
      b'-000.050\r\n'  → -0.050

    FORMAT 3 — plain ASCII integer × implied 100 (older firmware):
      b'+001195\r\n'  → divide by 100 → 11.95
      b'+011950\r\n'  → divide by 100 → 119.50
    """
    global _last_raw_hex
    if not raw:
        return None
    _last_raw_hex = raw.hex()

    #  Format 1: 13-byte binary SPC 
    if len(raw) >= 13 and raw[0] in (0x01, 0x02, 0x03, 0x04, 0x05):
        try:
            sign_byte  = raw[10]         # b'+' = 0x2B, b'-' = 0x2D
            digit_str  = raw[1:7].decode("ascii").strip()
            dec_pos    = raw[9]          # number of decimal places
            value      = int(digit_str) * (10 ** -dec_pos)
            if sign_byte == 0x2D:        # minus sign
                value = -value
            return round(value, 4)
        except Exception:
            pass  # fall through to ASCII parsers

    #  Format 2 & 3: ASCII 
    try:
        text = raw.decode("ascii", errors="ignore").strip()
        # Remove all non-numeric characters except sign and decimal point
        clean = re.sub(r"[^\d+\-.]", "", text)
        if not clean or len(clean) < 2:
            return None
        if "." in clean:
            # Format 2: already has decimal point
            return round(float(clean), 4)
        else:
            # Format 3: integer; determine scale by magnitude
            # Real MF values: 82–182 mm → raw integer 8200–18200 (×100)
            # Real CEC/ROD values: 79–125 mm → raw integer 7900–12500 (×100)
            # Values >999 are almost certainly ×100
            ival = int(clean)
            if ival > 999:
                return round(ival / 100.0, 4)
            return round(float(ival), 4)
    except Exception:
        pass

    return None


# NON-BLOCKING PACKET READ
def _read_one_packet() -> float | None:
    """
    Read available bytes from the serial buffer.
    Returns a parsed float when a complete packet is found, else None.
    Non-blocking (reads only bytes already in the OS buffer).
    """
    global _read_buf, _ser
    if not _ser or not _ser.is_open:
        return None
    try:
        waiting = _ser.in_waiting
        if waiting == 0:
            return None
        chunk      = _ser.read(waiting)
        _read_buf += chunk

        # SPC packet ends with CR (\r), LF (\n), ETX (\x03), or both
        # Scan for any terminator
        for term in (b"\r\n", b"\n\r", b"\r", b"\n", b"\x03"):
            if term in _read_buf:
                packet, _read_buf = _read_buf.split(term, 1)
                val = _parse_spc_packet(packet + term)
                if val is not None:
                    return val
                # Packet was malformed; discard and keep reading
                _read_buf = b""
                return None

        # If buffer is too large with no terminator, something is wrong — flush
        if len(_read_buf) > 64:
            print(f"[Mitutoyo] Buffer overflow, flushing: {_read_buf.hex()}")
            _read_buf = b""

    except serial.SerialException as exc:
        print(f"[Mitutoyo] Serial read error: {exc}")
        disconnect()
    return None


# PUBLIC MEASUREMENT API

def read_measurement() -> dict | None:
    """
    Called by Flask poll every ~600 ms.
    Accumulates values channel by channel (one value per DATA press).
    Returns complete dict when all channels are filled:
      {"CEC_TK": 119.5, "ROD_TK": 99.8, "MF": 152.3}
    Returns None while still collecting channels.
    """
    global _channel_buf
    with _lock:
        val = _read_one_packet()
        if val is None:
            return None

        # Assign value to the next unfilled channel in order
        for ch in CHANNEL_ORDER:
            if ch not in _channel_buf:
                _channel_buf[ch] = val
                print(f"[Mitutoyo] {ch} = {val} mm  (channel {len(_channel_buf)}/{len(CHANNEL_ORDER)})")
                break

        # All channels collected → return and reset
        if all(ch in _channel_buf for ch in CHANNEL_ORDER):
            result       = dict(_channel_buf)
            _channel_buf = {}
            return result

        return None   # still waiting for more channels


def get_pending_channel() -> str | None:
    """Return the name of the next channel awaiting a reading, or None if all done."""
    with _lock:
        for ch in CHANNEL_ORDER:
            if ch not in _channel_buf:
                return ch
    return None


def get_channel_progress() -> dict:
    """
    Return current collection state as dict.
    E.g. {"CEC_TK": 119.5, "ROD_TK": None, "MF": None}
    """
    with _lock:
        return {ch: _channel_buf.get(ch) for ch in CHANNEL_ORDER}


def reset_channel_buffer():
    """Discard any partially-collected measurement and start fresh."""
    global _channel_buf, _read_buf
    with _lock:
        _channel_buf = {}
        _read_buf    = b""
    print("[Mitutoyo] Channel buffer reset")


def clear_channel(channel: str):
    """
    Discard just ONE channel's reading (e.g. operator pressed DATA at the
    wrong moment and wants to re-measure only that dimension), leaving any
    other already-collected channels intact.
    """
    with _lock:
        _channel_buf.pop(channel, None)
    print(f"[Mitutoyo] Cleared channel {channel}")


def get_last_raw() -> str:
    """Return last received raw packet as hex string (for diagnostics)."""
    return _last_raw_hex


# AUTO-RECONNECT BACKGROUND THREAD

def _reconnect_loop():
    """Attempt to reconnect every 5 seconds when disconnected."""
    while True:
        time.sleep(5)
        if not (_ser and _ser.is_open):
            connect()


def start_background_reconnect():
    t = threading.Thread(
        target=_reconnect_loop,
        daemon=True,
        name="mitutoyo-reconnect",
    )
    t.start()


# MODULE INITIALISATION
connect()
start_background_reconnect()
