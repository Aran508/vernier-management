# =====================================================
# BARCODE SCANNER READER  —  Honeywell Voyager XP 1470G
# =====================================================
#
# The Honeywell 1470G supports two PC interface modes:
#
# MODE 1: USB HID  (factory default — RECOMMENDED)
# ──────────────────────────────────────────────────
#   The scanner emulates a USB keyboard.
#   Scanned barcode arrives as keystrokes ending with Enter.
#   No driver, no COM port, no server-side code needed.
#   The dashboard HTML captures keystrokes with a hidden <input>.
#   On a scan:
#     1. Browser receives keystroke stream into hidden input
#     2. JS calls /api/hid_scan with the barcode string
#     3. Server stores it in session as current_part_no
#
# MODE 2: USB Virtual COM  (requires EZConfig programming)
# ──────────────────────────────────────────────────
#   Requires: scan "USB Serial" barcode from 1470G manual, or
#             use Honeywell EZConfig → Interface → USB Serial.
#   Scanner appears as a COM port.
#   This module reads it and queues the barcode.
#   Set SCANNER_MODE = "serial" and SCANNER_PORT = "COM4" in config.py.
# =====================================================

import queue
import threading
import time

import serial
import serial.tools.list_ports

from config import SCANNER_MODE, SCANNER_PORT, SCANNER_BAUD

# STATE
_scan_queue = queue.Queue(maxsize=64)
_ser        = None
_running    = False
_status     = "hid" if SCANNER_MODE == "usb_hid" else "disconnected"


# SERIAL MODE  (virtual COM)

def _serial_reader_thread():
    """Background thread for virtual-COM scanner mode."""
    global _ser, _status
    while _running:
        try:
            if _ser is None or not _ser.is_open:
                _ser = serial.Serial(
                    port     = SCANNER_PORT,
                    baudrate = SCANNER_BAUD,
                    bytesize = 8,
                    parity   = "N",
                    stopbits = 1,
                    timeout  = 1.0,
                )
                _status = "connected"
                print(f"[Scanner] Connected (serial) on {SCANNER_PORT}")

            # readline blocks until \n or timeout
            raw = _ser.readline()
            if not raw:
                continue    # timeout, no data
            barcode = raw.decode("utf-8", errors="ignore").strip()
            # Strip GS1-128 / Code128 FNC1 characters if present
            barcode = barcode.replace("\x1d", "").replace("\x00", "").strip()
            if barcode:
                print(f"[Scanner] Scanned barcode: {barcode}")
                try:
                    _scan_queue.put_nowait(barcode)
                except queue.Full:
                    _scan_queue.get_nowait()   # drop oldest
                    _scan_queue.put_nowait(barcode)

        except serial.SerialException as exc:
            print(f"[Scanner] Serial error: {exc}")
            _status = "disconnected"
            if _ser:
                try:
                    _ser.close()
                except Exception:
                    pass
            _ser = None
            time.sleep(3)   # wait before retry

        except Exception as exc:
            print(f"[Scanner] Unexpected error: {exc}")
            time.sleep(1)


# PUBLIC API

def start_scanner():
    """Start the serial reader thread (only in serial mode)."""
    global _running
    if SCANNER_MODE == "usb_hid":
        print("[Scanner] USB HID mode — browser captures keystrokes, no serial thread needed.")
        return
    _running = True
    t = threading.Thread(
        target = _serial_reader_thread,
        daemon = True,
        name   = "scanner-serial",
    )
    t.start()
    print(f"[Scanner] Serial mode thread started on {SCANNER_PORT}")


def stop_scanner():
    global _running
    _running = False


def push_hid_scan(barcode: str):
    """
    Called by the Flask endpoint when the browser reports a HID scan.
    Puts the barcode into the shared queue so get_latest_scan() can return it.
    """
    barcode = barcode.strip()
    if barcode:
        try:
            _scan_queue.put_nowait(barcode)
        except queue.Full:
            _scan_queue.get_nowait()
            _scan_queue.put_nowait(barcode)


def get_latest_scan(timeout: float = 0.05) -> str | None:
    """
    Non-blocking poll; returns the next queued barcode or None.
    Used by /api/latest_scan for serial-mode polling.
    """
    try:
        return _scan_queue.get(timeout=timeout)
    except queue.Empty:
        return None


def get_scanner_status() -> str:
    """
    Return current scanner status string:
      "hid"          — USB HID keyboard-wedge mode (always "ready")
      "connected"    — serial mode, port open
      "disconnected" — serial mode, port not open
    """
    if SCANNER_MODE == "usb_hid":
        return "hid"
    return _status


def list_scanner_ports() -> list[dict]:
    """Return all serial ports (for setup UI port picker)."""
    return [
        {"port": p.device, "desc": p.description}
        for p in serial.tools.list_ports.comports()
    ]
