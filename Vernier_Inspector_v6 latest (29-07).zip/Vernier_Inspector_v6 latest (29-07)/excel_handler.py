# =====================================================
# EXCEL HANDLER  —  MCP Vernier Inspector v2.0
# =====================================================
#
# Workbook: data/MCPVERNIERDATA.xlsx
#
# Sheet "MCP DATA"    — Nominal part catalog (read-only reference)
#   A:S.No  B:Part Number  C:Mounting Face  D:CEC Thickness  E:Rod Eye Thickness
#
# Sheet "MCP MIN&MAX" — Tolerance master (read-only reference)
#   Row 1: column header
#   Row 2: sub-header (Min/Max labels)
#   Rows 3+: data rows, with brand header rows interspersed
#   Columns: A=S.NO  B=PART NO
#             C=MF Min  D=MF Max
#             E=CEC TK Min  F=CEC TK Max
#             G=ROD TK Min  H=ROD TK Max
#
# Sheet "OUTPUT"      — Measurement log (auto-created, append-only)
#   Date | Time | Part No | Brand | CEC TK(mm) | ROD TK(mm) | MF(mm) | Status
# =====================================================

import os
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from config import DATA_FILE, RANGE_FILE, UNIT

# Brand / category header labels that appear in column A or B of MCP MIN&MAX
_BRAND_LABELS = {
    "KOBELCO", "CATERPILLAR", "CAT 316", "CAT  3020GC", "CAT 3020GC",
    "JCB", "CNH", "XCMG 20 TON", "XCMG 14 TON",
    "PART NO", "S.NO", "KOBEL CO",
}

# Excel fill colours for status rows in OUTPUT sheet
_FILL = {
    "OK":             PatternFill("solid", fgColor="C8E6C9"),  # green
    "NOT OK":         PatternFill("solid", fgColor="FFCDD2"),  # red
    "PART NOT FOUND": PatternFill("solid", fgColor="FFF9C4"),  # yellow
}
_BOLD = Font(bold=True)


# UTILITIES

def _f(val) -> float | None:
    """Safe float conversion from cell value."""
    if val is None:
        return None
    s = str(val).strip()
    if s in ("", "-", "N/A", "n/a", "None"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _norm(part_no: str) -> str:
    """Normalise a part number to uppercase with no spaces."""
    return str(part_no).strip().upper().replace(" ", "")


def _expand_variants(raw: str) -> set[str]:
    """
    Expand a multi-part key into all possible normalised variants.

    Examples:
      "P14902/P14903"  → {"P14902/P14903", "P14902", "P14903"}
      "P14902/03"      → {"P14902/03", "P14902", "P14903"}
      "P13656/P13667"  → {"P13656/P13667", "P13656", "P13667"}
      "P9782/83/P14916/17/15358/59" → all numeric suffixes resolved
    """
    base     = _norm(raw)
    variants = {base}
    parts    = base.split("/")
    prefix   = ""

    for part in parts:
        if part.startswith("P") and any(c.isdigit() for c in part):
            prefix = "P"
            variants.add(part)
        elif part.isdigit():
            if prefix:
                variants.add(prefix + part)
            variants.add(part)
        else:
            variants.add(part)

    return variants


def _is_brand_row(row) -> tuple[bool, str]:
    """
    Check if this row is a brand/section header rather than a part data row.
    Returns (True, brand_name) or (False, "").
    """
    col_a = str(row[0]).strip().upper() if row[0] is not None else ""
    col_b = str(row[1]).strip().upper() if len(row) > 1 and row[1] is not None else ""

    # Brand rows: col A holds the brand name, col B is empty or also the name
    if col_a in _BRAND_LABELS:
        return True, col_a
    if col_b in _BRAND_LABELS and col_a in ("", "NONE"):
        return True, col_b

    # Row is a brand header if col A is not a number and col B is not a part number
    try:
        float(col_a)     # S.NO is a number → data row
    except ValueError:
        # col A is not a number
        if col_a and col_a not in ("", "NONE") and not col_a.startswith("P"):
            return True, col_a

    return False, ""


# INITIALISE OUTPUT SHEET

def create_files():
    """Create the OUTPUT sheet in the workbook if it doesn't exist."""
    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(
            f"Data file not found: {DATA_FILE}\n"
            "Place MCPVERNIERDATA.xlsx in the data/ folder."
        )
    wb = load_workbook(DATA_FILE)
    if "OUTPUT" not in wb.sheetnames:
        ws = wb.create_sheet("OUTPUT")
        headers = [
            "Date", "Time", "Part No", "Brand",
            f"CEC TK ({UNIT})", f"ROD TK ({UNIT})", f"MF ({UNIT})", "Status",
        ]
        ws.append(headers)
        hdr_fill = PatternFill("solid", fgColor="1A3A5C")
        for cell in ws[1]:
            cell.fill      = hdr_fill
            cell.font      = Font(bold=True, color="FFFFFF")
            cell.alignment = Alignment(horizontal="center")
        for i, w in enumerate([12, 10, 14, 14, 14, 14, 12, 12], 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = w
        wb.save(DATA_FILE)
        print("[XL] Created OUTPUT sheet in MCPVERNIERDATA.xlsx")
    else:
        print("[XL] OUTPUT sheet exists, ready.")


# RANGE MASTER  (Sheet: MCP MIN&MAX)
def get_all_ranges() -> list[dict]:
    """
    Parse the 'MCP MIN&MAX' sheet.
    Returns list of dicts, one per part number row:
    {
        "part_no":    "P14901",        ← normalised
        "brand":      "CATERPILLAR",
        "MF_min":     150.0,
        "MF_max":     156.0,
        "CEC_TK_min": 119.5,
        "CEC_TK_max": 120.0,
        "ROD_TK_min": 119.5,
        "ROD_TK_max": 120.0,
    }
    """
    wb = load_workbook(RANGE_FILE, read_only=True, data_only=True)
    if "MCP MIN&MAX" not in wb.sheetnames:
        wb.close()
        raise RuntimeError("Sheet 'MCP MIN&MAX' not found in MCPVERNIERDATA.xlsx")

    ws            = wb["MCP MIN&MAX"]
    result        = []
    current_brand = "UNKNOWN"

    # Skip rows 1–2 (header + sub-header)
    for row in ws.iter_rows(min_row=3, values_only=True):
        if not row or all(v is None for v in row):
            continue

        is_brand, brand_name = _is_brand_row(row)
        if is_brand:
            current_brand = brand_name
            continue

        # Part number is in column B (index 1)
        part_no_raw = row[1]
        if part_no_raw is None or str(part_no_raw).strip() == "":
            continue

        # Columns: 0=S.NO  1=PART_NO  2=MF_min  3=MF_max
        #          4=CEC_min  5=CEC_max  6=ROD_min  7=ROD_max
        result.append({
            "part_no":    _norm(part_no_raw),
            "brand":      current_brand,
            "MF_min":     _f(row[2]) if len(row) > 2 else None,
            "MF_max":     _f(row[3]) if len(row) > 3 else None,
            "CEC_TK_min": _f(row[4]) if len(row) > 4 else None,
            "CEC_TK_max": _f(row[5]) if len(row) > 5 else None,
            "ROD_TK_min": _f(row[6]) if len(row) > 6 else None,
            "ROD_TK_max": _f(row[7]) if len(row) > 7 else None,
        })

    wb.close()
    return result


def get_range_for_part(part_no: str) -> dict | None:
    """
    Find the tolerance record for a given part number.
    Handles multi-part keys like "P14902/P14903" — scanning "P14902" will match.
    Returns the range dict or None if not found.
    """
    query  = _norm(part_no)
    ranges = get_all_ranges()

    for r in ranges:
        # Direct match
        if r["part_no"] == query:
            return r
        # Expand stored key to all sub-variants
        stored_variants = _expand_variants(r["part_no"])
        if query in stored_variants:
            return r
        # Also: query might contain the stored key as substring
        # e.g. stored "P14902/P14903", query "P14902/P14903" → already caught above
        # But stored "P14902/P14903", query "P14902" → caught by expand_variants

    return None


def get_all_brands() -> list[str]:
    """Return sorted list of unique brand names."""
    return sorted({r["brand"] for r in get_all_ranges()})

# PART CATALOG  (Sheet: MCP DATA)

def get_nominal_data() -> list[dict]:
    """Return nominal specs from MCP DATA sheet."""
    wb = load_workbook(DATA_FILE, read_only=True, data_only=True)
    if "MCP DATA" not in wb.sheetnames:
        wb.close()
        return []
    ws  = wb["MCP DATA"]
    out = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or row[0] is None:
            continue
        out.append({
            "s_no":        row[0],
            "part_no":     _norm(row[1]) if row[1] else "",
            "mf_nominal":  str(row[2]).strip() if row[2] is not None else "",
            "cec_nominal": str(row[3]).strip() if row[3] is not None else "",
            "rod_nominal": str(row[4]).strip() if row[4] is not None else "",
        })
    wb.close()
    return out


# MEASUREMENT VALIDATION

def check_measurement(part_no: str, cec_tk: float, rod_tk: float, mf: float) -> str:
    """
    Compare measured values against tolerance.
    Returns: "OK", "NOT OK", or "PART NOT FOUND"
    A dimension with no min/max defined in the database is skipped (auto-pass).
    """
    r = get_range_for_part(part_no)
    if r is None:
        return "PART NOT FOUND"

    def within(val, lo, hi) -> bool:
        if lo is None or hi is None:
            return True   # not defined → skip
        return lo <= round(float(val), 4) <= hi

    if (within(cec_tk, r["CEC_TK_min"], r["CEC_TK_max"]) and
        within(rod_tk, r["ROD_TK_min"], r["ROD_TK_max"]) and
        within(mf,     r["MF_min"],     r["MF_max"])):
        return "OK"
    return "NOT OK"


def get_failure_detail(part_no: str, cec_tk: float, rod_tk: float, mf: float) -> list[str]:
    """
    Return a human-readable list of which dimensions are out of tolerance.
    E.g. ["CEC TK: 118.9 mm is BELOW min 119.5 mm (by 0.6 mm)"]
    """
    r = get_range_for_part(part_no)
    if r is None:
        return ["Part not in tolerance database"]

    issues = []

    def chk(label: str, val: float, lo, hi):
        if lo is None or hi is None:
            return
        v = round(float(val), 4)
        if v < lo:
            issues.append(
                f"{label}: {v} mm  BELOW min {lo} mm  (by {round(lo - v, 3)} mm)"
            )
        elif v > hi:
            issues.append(
                f"{label}: {v} mm  ABOVE max {hi} mm  (by {round(v - hi, 3)} mm)"
            )

    chk("CEC TK", cec_tk, r["CEC_TK_min"], r["CEC_TK_max"])
    chk("ROD TK", rod_tk, r["ROD_TK_min"], r["ROD_TK_max"])
    chk("MF",     mf,     r["MF_min"],     r["MF_max"])
    return issues


# SAVE MEASUREMENT  (Sheet: OUTPUT)

def save_measurement(date: str, time_str: str, part_no: str,
                     cec_tk: float, rod_tk: float, mf: float, status: str):
    """Append one measurement row to the OUTPUT sheet."""
    r     = get_range_for_part(part_no)
    brand = r["brand"] if r else "UNKNOWN"

    wb = load_workbook(DATA_FILE)
    if "OUTPUT" not in wb.sheetnames:
        create_files()
        wb = load_workbook(DATA_FILE)
    ws = wb["OUTPUT"]

    row_values = [
        date, time_str, part_no, brand,
        round(float(cec_tk), 3),
        round(float(rod_tk), 3),
        round(float(mf), 3),
        status,
    ]
    ws.append(row_values)

    # Colour-code the entire row
    last_row = ws.max_row
    fill     = _FILL.get(status, PatternFill("solid", fgColor="FFFFFF"))
    for col in range(1, 9):
        ws.cell(last_row, col).fill = fill
    ws.cell(last_row, 8).font = _BOLD   # bold status cell

    wb.save(DATA_FILE)
    print(f"[XL] Saved: {part_no} | CEC={cec_tk} ROD={rod_tk} MF={mf} | {status}")


# READ MEASUREMENTS  (Sheet: OUTPUT)

def get_all_measurements() -> list[dict]:
    """Return all saved measurements, newest first."""
    wb = load_workbook(DATA_FILE, read_only=True, data_only=True)
    if "OUTPUT" not in wb.sheetnames:
        wb.close()
        return []
    ws  = wb["OUTPUT"]
    out = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or row[0] is None:
            continue
        out.append({
            "date":    str(row[0]),
            "time":    str(row[1]),
            "part_no": str(row[2]) if row[2] else "",
            "brand":   str(row[3]) if row[3] else "",
            "CEC_TK":  float(row[4]) if row[4] is not None else 0.0,
            "ROD_TK":  float(row[5]) if row[5] is not None else 0.0,
            "MF":      float(row[6]) if row[6] is not None else 0.0,
            "status":  str(row[7]) if row[7] else "",
        })
    wb.close()
    return list(reversed(out))


# REPORT SUMMARY

def get_report_summary() -> dict:
    data    = get_all_measurements()
    total   = len(data)
    passed  = sum(1 for m in data if m["status"] == "OK")
    failed  = sum(1 for m in data if m["status"] == "NOT OK")
    notfnd  = total - passed - failed

    part_stats  = {}
    brand_stats = {}

    for m in data:
        p = m["part_no"]
        b = m.get("brand", "UNKNOWN") or "UNKNOWN"

        if p not in part_stats:
            part_stats[p] = {"pass": 0, "fail": 0, "brand": b}
        if m["status"] == "OK":
            part_stats[p]["pass"] += 1
        else:
            part_stats[p]["fail"] += 1

        if b not in brand_stats:
            brand_stats[b] = {"pass": 0, "fail": 0}
        if m["status"] == "OK":
            brand_stats[b]["pass"] += 1
        else:
            brand_stats[b]["fail"] += 1

    trend = list(reversed(data[:50]))   # last 50, chronological

    return {
        "total":       total,
        "passed":      passed,
        "failed":      failed,
        "not_found":   notfnd,
        "yield_pct":   round(passed / total * 100, 1) if total else 0,
        "part_stats":  part_stats,
        "brand_stats": brand_stats,
        "trend":       trend,
    }
