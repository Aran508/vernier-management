#!/usr/bin/env python3
# =====================================================
# SCHEDULER - Daily Email Report Scheduler
# =====================================================

import logging
import threading
import schedule
import time
from config import EMAIL_ENABLED, EMAIL_SCHEDULE_HOUR, EMAIL_SCHEDULE_MIN
from email_handler import send_daily_report

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter('[SCHEDULER] %(message)s'))
logger.addHandler(handler)

scheduler_thread = None
scheduler_running = False


def schedule_jobs():
    """Schedule the daily email report."""
    if not EMAIL_ENABLED:
        logger.info("Email scheduling disabled (EMAIL_ENABLED=False)")
        return
    
    schedule_time = f"{EMAIL_SCHEDULE_HOUR:02d}:{EMAIL_SCHEDULE_MIN:02d}"
    logger.info(f"Scheduling daily email report at {schedule_time}")
    
    schedule.every().day.at(schedule_time).do(send_daily_report)


def run_scheduler():
    """Run the scheduler in a loop."""
    global scheduler_running
    scheduler_running = True
    
    logger.info("Scheduler started")
    
    while scheduler_running:
        try:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
        except Exception as e:
            logger.error(f"Scheduler error: {e}")
            time.sleep(60)


def start_scheduler():
    """Start the scheduler in a background thread."""
    global scheduler_thread, scheduler_running
    
    if scheduler_running:
        logger.warning("Scheduler is already running")
        return
    
    if not EMAIL_ENABLED:
        logger.info("Email scheduling is disabled")
        return
    
    schedule_jobs()
    
    # Start scheduler in background thread
    scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
    scheduler_thread.start()
    
    logger.info("Scheduler thread started")


def stop_scheduler():
    """Stop the scheduler."""
    global scheduler_running
    scheduler_running = False
    logger.info("Scheduler stopped")


def get_scheduler_status():
    """Get current scheduler status."""
    return {
        'enabled': EMAIL_ENABLED,
        'running': scheduler_running,
        'schedule_time': f"{EMAIL_SCHEDULE_HOUR:02d}:{EMAIL_SCHEDULE_MIN:02d}",
        'jobs': len(schedule.jobs)
    }
